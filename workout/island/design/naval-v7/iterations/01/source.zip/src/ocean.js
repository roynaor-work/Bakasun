import * as THREE from '../vendor/three.module.js';

// Shared analytic sea surface: effects and wake vertices use the same phase.
export const waveGLSL=`
float sea(vec2 p,float t){
 return sin(dot(p,vec2(.105,.074))-t*.85)*.48
       +sin(dot(p,vec2(-.17,.21))-t*1.12)*.22
       +sin(dot(p,vec2(.41,.13))+t*1.42)*.08;
}
vec2 seaSlope(vec2 p,float t){
 return cos(dot(p,vec2(.105,.074))-t*.85)*.48*vec2(.105,.074)
       +cos(dot(p,vec2(-.17,.21))-t*1.12)*.22*vec2(-.17,.21)
       +cos(dot(p,vec2(.41,.13))+t*1.42)*.08*vec2(.41,.13);
}`;
const noiseGLSL=`
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){return noise(p)*.57+noise(p*2.04+7.2)*.28+noise(p*4.1-3.7)*.15;}
`;
const skyGLSL=`
vec3 skyColor(vec3 d,float storm,float t){
 float h=max(0.,d.y);
 vec3 warm=mix(vec3(.67,.38,.24),vec3(.76,.65,.48),smoothstep(-.04,.12,d.y));
 vec3 cool=mix(vec3(.25,.36,.45),vec3(.055,.14,.23),smoothstep(.05,.9,h));
 vec3 c=mix(warm,cool,smoothstep(0.,.44,h));
 vec3 sun=normalize(vec3(-.66,.14,-.53));float glow=max(0.,dot(d,sun));
 c+=vec3(.62,.24,.075)*pow(glow,18.)*(1.-storm*.8);
 c+=vec3(2.8,1.8,.68)*smoothstep(.99955,.99984,glow)*(1.-storm*.95);
 return mix(c,mix(vec3(.23,.29,.33),vec3(.075,.13,.18),smoothstep(0.,.6,h)),storm*.78);
}`;

export function createAtmosphere(scene){
 const uniforms={uTime:{value:0},uStorm:{value:0}};
 const material=new THREE.ShaderMaterial({uniforms,side:THREE.BackSide,depthWrite:false,
  vertexShader:`varying vec3 vDir;void main(){vDir=position;vec4 p=projectionMatrix*mat4(mat3(viewMatrix))*vec4(position,1.);gl_Position=p.xyww;}`,
  fragmentShader:`uniform float uTime,uStorm;varying vec3 vDir;${noiseGLSL}${skyGLSL}
  void main(){
   vec3 d=normalize(vDir);vec3 c=skyColor(d,uStorm,uTime);
   vec2 p=d.xz/(max(.13,d.y)+.25)*2.8+vec2(uTime*.006,-uTime*.004);
   float cloud=fbm(p);float layer=smoothstep(.46-uStorm*.12,.74-uStorm*.08,cloud);
   layer*=smoothstep(-.025,.16,d.y)*(1.-smoothstep(.8,1.,d.y));
   vec3 cloudColor=mix(vec3(.40,.43,.45),vec3(.095,.135,.17),uStorm*.8);
   cloudColor+=vec3(.22,.10,.035)*(1.-cloud)*(1.-uStorm);
   c=mix(c,cloudColor,layer*(.58+uStorm*.34));
   float shelf=fbm(p*.47+vec2(5.,uTime*.001));
   c=mix(c,vec3(.10,.15,.20),smoothstep(.56,.76,shelf)*smoothstep(.07,.3,d.y)*(.18+.6*uStorm));
   gl_FragColor=vec4(c,1.);
   #include <tonemapping_fragment>
   #include <colorspace_fragment>
  }`});
 const sky=new THREE.Mesh(new THREE.SphereGeometry(1500,24,12),material);sky.frustumCulled=false;sky.renderOrder=-10;scene.add(sky);
 return {uniforms,sky,dispose(){sky.geometry.dispose();material.dispose();}};
}

export function createOcean(scene,normalMap){
 normalMap.wrapS=normalMap.wrapT=THREE.RepeatWrapping;normalMap.colorSpace=THREE.NoColorSpace;
 const uniforms={uTime:{value:0},uStorm:{value:0},uNormal:{value:normalMap},uAmplitude:{value:1},uQuality:{value:1},uIsland:{value:new THREE.Vector3(83,-93,40)}};
 const material=new THREE.ShaderMaterial({uniforms,
  vertexShader:`uniform float uTime,uAmplitude;varying vec3 vWorld;varying float vCrest;${waveGLSL}
   void main(){vec3 p=position;float h=sea(p.xz,uTime)*uAmplitude;p.y=h;vWorld=p;vCrest=h;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,
  fragmentShader:`uniform float uTime,uStorm,uAmplitude,uQuality;uniform sampler2D uNormal;uniform vec3 uIsland;varying vec3 vWorld;varying float vCrest;${waveGLSL}${noiseGLSL}${skyGLSL}
   void main(){
    vec2 p=vWorld.xz;vec2 slope=seaSlope(p,uTime)*uAmplitude;
    vec3 n1=texture2D(uNormal,p*.026+vec2(uTime*.013,-uTime*.006)).xyz*2.-1.;
    vec3 n2=texture2D(uNormal,p*.053+vec2(-uTime*.009,uTime*.011)).xyz*2.-1.;
    vec3 N=normalize(vec3(-slope.x+(n1.x+n2.y)*.25,1.,-slope.y+(n1.y+n2.x)*.25));
    vec3 V=normalize(cameraPosition-vWorld);vec3 R=reflect(-V,N);
    float fresnel=.035+.72*pow(1.-max(0.,dot(V,N)),4.);
    vec3 deep=mix(vec3(.018,.105,.145),vec3(.025,.095,.13),uStorm);
    vec3 shallow=vec3(.045,.22,.235);
    float dist=length(vWorld.xz-uIsland.xy);float shoal=(1.-smoothstep(uIsland.z*.75,uIsland.z+17.,dist));
    vec3 water=mix(deep,shallow,shoal*.65)+vec3(.012,.035,.035)*(N.y*.5+.5);
    vec3 reflected=skyColor(R,uStorm,uTime);
    vec3 c=mix(water,reflected,fresnel);
    vec3 sun=normalize(vec3(-.66,.14,-.53));vec3 H=normalize(sun+V);
    float spec=pow(max(0.,dot(N,H)),120.);c+=vec3(1.1,.65,.26)*spec*(1.-uStorm*.9);
    float grain=noise(p*.7+vec2(uTime*.16));
    float crest=smoothstep(.47,.69,vCrest/uAmplitude+grain*.13)*(.25+.4*uStorm);
    float shore=1.-smoothstep(.0,3.2,abs(dist-uIsland.z+sin(atan(p.y-uIsland.y,p.x-uIsland.x)*5.)*2.5));
    shore*=smoothstep(.2,.7,grain+sin(dist*2.-uTime*1.4)*.22)*.7;
    float foam=clamp((crest+shore)*(.5+grain*.5),0.,.85);
    c=mix(c,vec3(.63,.76,.74),foam);
    float fog=smoothstep(180.,1100.,length(vWorld-cameraPosition));c=mix(c,skyColor(normalize(vec3(vWorld.x-cameraPosition.x,.006,vWorld.z-cameraPosition.z)),uStorm,uTime),fog);
    gl_FragColor=vec4(c,1.);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
   }`});
 // Central patch is dense; outer ring has long waves and avoids a 2400m dense grid.
 const geometry=new THREE.PlaneGeometry(520,520,100,100);geometry.rotateX(-Math.PI/2);
 const mesh=new THREE.Mesh(geometry,material);mesh.frustumCulled=false;scene.add(mesh);
 const outerGeometry=new THREE.PlaneGeometry(3000,3000,24,24);outerGeometry.rotateX(-Math.PI/2);
 const outer=new THREE.Mesh(outerGeometry,material);outer.position.y=-.15;outer.renderOrder=-1;outer.frustumCulled=false;scene.add(outer);
 return {mesh,uniforms,material,dispose(){geometry.dispose();outerGeometry.dispose();material.dispose();}};
}

export function createWake(scene,length,beam){
 const uniforms={uTime:{value:0},uLength:{value:length},uBeam:{value:beam},uStrength:{value:1},uAmplitude:{value:1}};
 const geo=new THREE.PlaneGeometry(beam*5,length*2.3,1,28);geo.rotateX(-Math.PI/2);geo.translate(0,0,-length*.25);
 const mat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms,
  vertexShader:`uniform float uTime,uAmplitude;varying vec3 vLocal;varying vec3 vWorld;${waveGLSL}
   void main(){vLocal=position;vec4 w=modelMatrix*vec4(position,1.);w.y=sea(w.xz,uTime)*uAmplitude+.055;vWorld=w.xyz;gl_Position=projectionMatrix*viewMatrix*w;}`,
  fragmentShader:`uniform float uTime,uLength,uBeam,uStrength;varying vec3 vLocal;varying vec3 vWorld;${noiseGLSL}
   void main(){
    float x=abs(vLocal.x),z=vLocal.z;float stern=-uLength*.47;
    float behind=max(0.,stern-z);float trail=1.-smoothstep(0.,uLength*.9,behind);
    float spread=uBeam*.45+behind*.28;
    float v=1.-smoothstep(.15,1.1,abs(x-spread));
    float churn=(1.-smoothstep(uBeam*.2,uBeam*.63,x))*trail*.45;
    float wake=(v*trail*.65+churn)*step(z,stern);
    float hull=(1.-smoothstep(.25,1.15,abs(x-uBeam*.49)))*(1.-smoothstep(uLength*.30,uLength*.48,abs(z)));
    float bow=1.-smoothstep(.2,1.2,abs(length(vec2(vLocal.x*1.7,(z-uLength*.27)*.65))-uBeam*.54));
    bow*=step(uLength*.25,z);wake+=hull*.45+bow*.65;
    float grit=fbm(vWorld.xz*.65+vec2(0,uTime*.9));
    float a=clamp(wake*mix(.2,1.,grit)*uStrength,0.,.72);
    gl_FragColor=vec4(mix(vec3(.32,.54,.55),vec3(.78,.84,.76),grit),a);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
   }`});
 const wake=new THREE.Mesh(geo,mat);wake.renderOrder=2;scene.add(wake);
 return {mesh:wake,uniforms,dispose(){geo.dispose();mat.dispose();}};
}

export function waveHeight(x,z,t,amplitude=1){
 return (Math.sin(x*.105+z*.074-t*.85)*.48+Math.sin(-x*.17+z*.21-t*1.12)*.22+Math.sin(x*.41+z*.13+t*1.42)*.08)*amplitude;
}
