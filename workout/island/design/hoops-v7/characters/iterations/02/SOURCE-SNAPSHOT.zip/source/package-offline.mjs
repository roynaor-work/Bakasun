/** Authoring utility: packs the local preview into one file:// capable HTML.
 * No build or network access is needed to open the resulting standalone.html.
 * Run: node source/package-offline.mjs --modules /tmp/hoops-v7-tools
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const requested=process.argv.includes('--modules')?process.argv[process.argv.indexOf('--modules')+1]:'/tmp/hoops-v7-tools';
const require=createRequire(path.resolve(requested,'package.json'));
const {build}=require('esbuild');
const profiles=['pg','sg','sf','pf','c','referee'];
const names=profiles.flatMap(id=>[`models/${id}.glb`,`models/${id}-lod1.glb`]);
names.push('vendor/draco/draco_wasm_wrapper.js','vendor/draco/draco_decoder.wasm');
names.push('rig.json','model-authoring.json');
const files={};for(const name of names)files[name]=(await fs.readFile(path.join(root,name))).toString('base64');
const result=await build({entryPoints:[path.join(root,'preview.mjs')],bundle:true,write:false,minify:true,format:'iife',platform:'browser',target:['es2020'],legalComments:'inline'});
const css=await fs.readFile(path.join(root,'preview.css'),'utf8');
let html=await fs.readFile(path.join(root,'index.html'),'utf8');
html=html.replace('<link rel="stylesheet" href="preview.css">',`<style>${css}</style>`);
const pack=JSON.stringify({version:1,files}).replace(/<\//g,'<\\/');
const js=result.outputFiles[0].text.replace(/<\/script/gi,'<\\/script');
html=html.replace('<script type="module" src="preview.mjs"></script>',`<script>window.__HOOPS_PACK__=${pack};</script><script>${js}</script>`);
// The report link is useful in the modular preview. The self-contained artifact
// carries a text copy of the report when available, without filesystem requests.
try{const report=await fs.readFile(path.join(root,'REPORT.md'),'utf8');html=html.replace('<a href="REPORT.md">דוח הנכסים והבדיקות ↗</a>','<a href="#" id="offline-report">דוח הנכסים והבדיקות ↗</a>');html=html.replace('</body>',`<script>document.getElementById('offline-report').addEventListener('click',function(event){event.preventDefault();const blob=new Blob([${JSON.stringify(report).replace(/<\//g,'<\\/')}],{type:'text/markdown;charset=utf-8'});const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download='REPORT.md';link.click();setTimeout(function(){URL.revokeObjectURL(link.href)},1000)});</script></body>`);}catch{}
const destination=path.join(root,'standalone.html');await fs.writeFile(destination,html);
console.log(JSON.stringify({path:path.relative(root,destination),bytes:Buffer.byteLength(html),embeddedGLBs:profiles.length*2,threeRevision:160,noNetworkRequired:true},null,2));
