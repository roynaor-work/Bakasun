/**
 * Original basketball presentation motion, authored for the canonical 18 joints.
 * Coordinates are metres, +Y up, +Z forward, +X anatomical left.
 * No gameplay, ownership, collision or score is inferred from animation time.
 * The same target-space solver is used for live playback and baked GLB clips.
 */
import * as THREE from '../vendor/three.module.js';

export const BONE_NAMES = Object.freeze(['Root','Hips','Spine','Chest','Neck','Head',
  'LeftArm','LeftForeArm','LeftHand','RightArm','RightForeArm','RightHand',
  'LeftUpLeg','LeftLeg','LeftFoot','RightUpLeg','RightLeg','RightFoot']);

export const ACTIONS = Object.freeze([
  ['idle_hold','החזקת כדור','Ball hold',2.4,true,'control'],
  ['idle','עמידה ללא כדור','Ready without ball',2.8,true,'locomotion'],
  ['dribble_right','כדרור ימין','Right-hand dribble',.78,true,'dribble'],
  ['dribble_left','כדרור שמאל','Left-hand dribble',.82,true,'dribble'],
  ['dribble_power','כדרור כוח והגנה','Protective power dribble',.90,true,'dribble'],
  ['dribble_crossover','כדרור צולב','Crossover dribble',1.18,true,'dribble'],
  ['dribble_between_legs','כדרור בין הרגליים','Between-the-legs dribble',1.32,true,'dribble'],
  ['shot_set','קליעה מהמקום','Set shot',1.75,false,'shot'],
  ['shot_jump','קליעה בקפיצה','Jump shot',1.60,false,'shot'],
  ['shot_fadeaway','קליעה בנסיגה באוויר','Fadeaway shot',1.90,false,'shot'],
  ['shot_stepback','צעד לאחור וקליעה','Step-back shot',2.10,false,'shot'],
  ['layup','לייאפ','Right-hand layup',1.70,false,'finish'],
  ['dunk_one_hand','דאנק ביד אחת','One-hand dunk',1.85,false,'finish'],
  ['dunk_two_hand','דאנק בשתי ידיים','Two-hand dunk',1.95,false,'finish'],
  ['dunk_reverse','דאנק אחורי','Reverse dunk',2.15,false,'finish'],
  ['euro_step','רב-צעד ואיסוף','Euro-step gather',1.75,false,'control'],
  ['run','ריצה','Run',.72,true,'locomotion'],
  ['decelerate','האטה ובלימה','Deceleration',1.35,false,'locomotion'],
  ['defense_shuffle','הגנה בצעדי צד','Defensive lateral shuffle',1.18,true,'defense'],
  ['steal','חטיפה','Reach-in steal',1.15,false,'defense'],
  ['block','חסימה','Jump block',1.45,false,'defense'],
  ['rebound','ריבאונד ואחיזה','Rebound and secure',1.75,false,'control'],
  ['walk','צעדים ללא כדור','Walk without ball',1.30,true,'locomotion'],
  ['pivot','עבודת רגליים ללא כדור','Pivot footwork',1.85,true,'locomotion'],
  ['celebrate','חגיגה','Restrained victory celebration',2.30,false,'expression'],
  ['fall','נפילה והתאוששות','Side fall and recovery',2.80,false,'expression'],
  ['referee_signal','סימון שופט','Referee signal',2.35,false,'expression'],
].map(([id,label,labelEn,duration,loop,category])=>Object.freeze({id,label,labelEn,duration,loop,category})));
const CATALOG = Object.fromEntries(ACTIONS.map(a=>[a.id,a]));
const TAU = Math.PI*2, V = a=>new THREE.Vector3(...a), Q = ()=>new THREE.Quaternion();
const clamp = (x,a=0,b=1)=>Math.min(b,Math.max(a,x));
const mix = (a,b,t)=>a+(b-a)*t;
const smooth = x=>{x=clamp(x);return x*x*(3-2*x);};
const ramp = (p,a,b)=>smooth((p-a)/(b-a));
const pulse = (p,a,b,c,d)=>ramp(p,a,b)*(1-ramp(p,c,d));
const lerp3 = (a,b,t)=>a.map((x,i)=>mix(x,b[i],t));
const add3 = (a,b)=>a.map((x,i)=>x+b[i]);
const normalized = a=>{const l=Math.hypot(...a)||1;return a.map(x=>x/l);};
const copy = x=>Array.isArray(x)?x.map(copy):(x&&typeof x==='object'?Object.fromEntries(Object.entries(x).map(([k,v])=>[k,copy(v)])):x);
function blend(a,b,t){
  if(typeof a==='number')return mix(a,b,t);
  if(Array.isArray(a))return a.map((v,i)=>blend(v,b[i],t));
  if(a&&typeof a==='object')return Object.fromEntries(Object.keys(a).map(k=>[k,blend(a[k],b[k],t)]));
  return t<.5?a:b;
}
function arc(p,a,b,height){const t=clamp((p-a)/(b-a));return Math.sin(Math.PI*t)*height;}

function blankPose(m){
  const {h,ankleY,footX,hipsY}=m;
  return {
    hips:[0,0,0],hipsRotation:[0,0,0],spine:[0,0,0],chest:[0,0,0],neck:[0,0,0],head:[0,0,0],
    leftFoot:[footX,ankleY,0],rightFoot:[-footX,ankleY,0],
    leftFootRotation:[0,0,0],rightFootRotation:[0,0,0],leftSupport:1,rightSupport:1,
    left:{wrist:[.14*h,.55*h,.025],normal:[0,0,1],fingers:[0,-1,0],contact:0,offset:[1,0,0]},
    right:{wrist:[-.14*h,.55*h,.025],normal:[0,0,1],fingers:[0,-1,0],contact:0,offset:[-1,0,0]},
    ball:[0,.60*h,.34],ballVisible:0,ballRotation:[0,0,0],hipsY,
  };
}
function hold(p,m,ball=[0,.65*m.h,.30]){
  p.ball=ball;p.ballVisible=1;
  for(const [key,sign] of [['left',1],['right',-1]]){
    p[key].contact=1;p[key].offset=normalized([sign,.04,-.16]);
    p[key].fingers=normalized([-.15*sign,-.12,1]);
  }
  return p;
}
function softReady(p,m){
  p.hips[1]=-.035*m.h;p.spine[0]=.04;
  p.left.wrist=[.15*m.h,.55*m.h,.11];p.right.wrist=[-.15*m.h,.55*m.h,.11];
}
function dribblePose(id,phase,m){
  const p=blankPose(m),{h}=m;
  const transfer=id==='dribble_crossover'||id==='dribble_between_legs';
  const two=phase*2,half=Math.floor(two),u=transfer?two-half:phase;
  const side=id==='dribble_left'?1:(transfer?(half%2===0?-1:1):-1);
  const power=id==='dribble_power',between=id==='dribble_between_legs';
  const top=h*(power?.43:between?.42:.51),r=m.ballRadius;
  const y=r+(top-r)*(2*u-1)**2;
  const s=transfer?-side*Math.cos(Math.PI*u):0;
  const x=transfer?-s*h*.185:side*h*(power?.245:.195);
  const z=between?mix(.35,-.14,ramp(u,.14,.84)):(power?.18:.35);
  p.ball=[x,y,z];p.ballVisible=1;p.ballRotation=[-phase*TAU*2,0,phase*TAU*.35];
  p.hips=[(transfer?Math.sin(phase*TAU)*.035:side*.015)*h,-h*(between?.14:power?.14:.09)-.008*Math.sin(phase*TAU*2),0];
  p.spine=[between?.20:power?.16:.12,0,side*.012];p.chest=[0,side*(power?.20:.07),0];p.head=[-.05,-side*.055,0];
  p.leftFoot=[m.footX+(between?.08:.025),m.ankleY,between?-.10:-.045];
  p.rightFoot=[-m.footX-(between?.08:.025),m.ankleY,between?.12:.065];
  if(transfer&&half%2===1&&between)p.ball[2]=mix(-.14,.35,ramp(u,.14,.84));
  for(const [key,sgn] of [['left',1],['right',-1]]){
    const outgoing=sgn===side,incoming=transfer?sgn===-side:outgoing;
    const a=outgoing?1-ramp(u,.025,.08):0,b=incoming?ramp(u,.92,.975):0;
    p[key].contact=Math.max(a,b);p[key].offset=[0,1,0];p[key].fingers=[0,-.05,1];
    p[key].wrist=[sgn*h*.19,h*(outgoing?.54:.62),outgoing?.31:.26];
    p[key].normal=[0,-1,0];
    if(power&&!outgoing){p[key].wrist=[sgn*.27*h,.61*h,.34];p[key].fingers=[0,0,1];}
  }
  return p;
}
function shotPose(id,t,m){
  const p=hold(blankPose(m),m),{h}=m;
  const set=id==='shot_set',fade=id==='shot_fadeaway',step=id==='shot_stepback';
  const load=pulse(t,.0,.16,.24,.43),rise=ramp(t,.18,.48),recover=ramp(t,.73,1);
  const jump=set?0:arc(t,.24,.82,fade?.28:.23);
  p.hips[1]=-h*.075*load+jump;
  p.hips[2]=(fade?-.30*ramp(t,.25,.75):step?-.36*pulse(t,.05,.3,.84,1):0);
  p.spine=[fade?-.10*rise:.035*load,0,0];p.chest=[0,-.10,0];p.head=[-.10,0,0];
  const release=.49,follow=pulse(t,.45,.53,.76,.95);
  const gather=[-.055,h*.69,.30],releaseBall=[-.065,h*.91+jump,.23];
  p.ball=lerp3(gather,releaseBall,rise);
  if(t>release){
    const s=(t-release)*CATALOG[id].duration;
    const releaseJump=set?0:arc(release,.24,.82,fade?.28:.23);
    p.ball=[-.065,h*.91+releaseJump+3.8*s-4.905*s*s,.23+4.0*s];
  }
  p.ballRotation=[-t*TAU*1.7,0,0];
  p.right.offset=normalized([-.08,-1,-.12]);p.right.fingers=[0,.18,1];
  p.left.offset=normalized([1,.0,-.10]);p.left.fingers=[-.2,.1,1];
  p.right.contact=1-ramp(t,.49,.525);p.left.contact=1-ramp(t,.43,.485);
  p.right.wrist=[-.09*h,h*.91+jump-.05,.29+.11*follow];
  p.left.wrist=[.18*h,h*(.70+.10*follow)+jump,.27];
  p.right.normal=normalized([.0,.45,1]);p.right.fingers=[0,.65,1];
  p.left.normal=[0,0,1];p.left.fingers=[0,.4,1];
  if(recover>0){p.right.wrist=lerp3(p.right.wrist,[-.23*h,.48*h,.10],recover);p.left.wrist=lerp3(p.left.wrist,[.23*h,.48*h,.10],recover);}
  p.leftFoot=[m.footX,m.ankleY+jump,step?-.21*ramp(t,.08,.28):.035];
  p.rightFoot=[-m.footX,m.ankleY+jump,step?-.28*ramp(t,.13,.34):.10];
  p.leftSupport=set?1:(t>.24&&t<.82?0:1);p.rightSupport=p.leftSupport;
  p.leftFootRotation[0]=p.rightFootRotation[0]=-.10*Math.sin(Math.PI*rise)*(1-recover);
  p.ballVisible=t<.96?1:0;
  return p;
}
function layupPose(t,m){
  const p=hold(blankPose(m),m),{h}=m;
  const takeoff=.34,land=.84,jump=arc(t,takeoff,land,.40),lift=ramp(t,.20,.57);
  p.hips=[.025,-.07*pulse(t,.0,.12,.25,.40)+jump,.27*pulse(t,.05,.33,.83,1)];
  p.spine=[.07,0,-.035];p.chest=[0,-.15,0];p.head=[-.16,0,0];
  p.ball=lerp3([-.04,.69*h,.30],[-.075,1.0*h+jump,.35],lift);
  if(t>.58){const s=(t-.58)*CATALOG.layup.duration;p.ball=[-.075,1.0*h+arc(.58,takeoff,land,.40)+2.5*s-4.905*s*s,.35+2.8*s];}
  p.right.offset=[0,-1,0];p.right.fingers=[0,.3,1];p.right.contact=1-ramp(t,.58,.61);
  p.left.contact=1-ramp(t,.31,.39);p.left.wrist=[.25*h,.66*h+jump,.10];
  p.right.wrist=[-.08*h,.98*h+jump,.39];p.right.normal=[0,.6,1];p.right.fingers=[0,.5,1];
  const knee=arc(t,.28,.75,.29);
  p.leftFoot=[m.footX,m.ankleY+jump,-.09];p.rightFoot=[-m.footX,m.ankleY+jump+knee,.23];
  p.leftFootRotation[0]=-.15;p.rightFootRotation[0]=-.35*knee;
  p.leftSupport=t>takeoff&&t<land?0:1;p.rightSupport=t>.23&&t<land?0:1;
  p.ballVisible=t<.97?1:0;return p;
}
function dunkPose(id,t,m){
  const p=hold(blankPose(m),m),{h}=m;
  const two=id==='dunk_two_hand',reverse=id==='dunk_reverse',takeoff=.29,land=.86;
  const amplitude=Math.max(.45,3.13-(m.shoulderY+m.armReach+.10));
  const jump=arc(t,takeoff,land,amplitude),up=ramp(t,.23,.49),down=ramp(t,.57,.68);
  p.hips=[0,-.11*pulse(t,.02,.16,.25,.36)+jump,.12*pulse(t,.05,.32,.86,1)];
  p.spine=[mix(.12,-.075,up)+.19*down,0,0];p.chest=[0,reverse?Math.PI*ramp(t,.28,.56):-.08,0];
  p.head=[-.16*(1-down),reverse?-.12:0,0];
  const raised=[two?0:-.08,Math.min(h*1.03+jump,3.17),reverse?-.23:.20];
  p.ball=lerp3([-.03,.69*h,.30],raised,up);
  p.ball[1]-=.23*down;
  if(t>.64){const s=(t-.64)*CATALOG[id].duration;p.ball=[reverse?0:-.05,2.96-2.3*s-4.905*s*s,reverse?-.26:.22];}
  p.right.offset=two?normalized([-.80,-.35,-.2]):[0,-1,0];p.right.fingers=reverse?[0,0,-1]:[0,.1,1];
  p.left.offset=normalized([.80,-.35,-.2]);p.left.fingers=reverse?[0,0,-1]:[0,.1,1];
  p.right.contact=1-ramp(t,.63,.67);p.left.contact=two?1-ramp(t,.63,.67):1-ramp(t,.25,.35);
  p.right.wrist=[-.10*h,h*1.01+jump-.04-.23*down,reverse?-.28:.23];
  p.left.wrist=two?[.10*h,h*1.01+jump-.04-.23*down,reverse?-.28:.23]:[.26*h,h*.68+jump,-.16];
  p.right.normal=[0,-.3,reverse?-1:1];p.right.fingers=[0,-1,reverse?-1:1];
  p.left.normal=[0,0,1];p.left.fingers=[0,.9,.2];
  const tuck=arc(t,.33,.78,.26);
  p.leftFoot=[m.footX,m.ankleY+jump+tuck*.3,-.15];p.rightFoot=[-m.footX,m.ankleY+jump+tuck,-.18];
  p.leftFootRotation[0]=-.18;p.rightFootRotation[0]=-.32;
  p.leftSupport=p.rightSupport=t>takeoff&&t<land?0:1;
  p.ballVisible=t<.95?1:0;return p;
}
function locomotion(id,t,m){
  const p=blankPose(m),{h}=m,s=Math.sin(t*TAU),c=Math.cos(t*TAU);
  if(id==='idle'){
    softReady(p,m);p.hips[1]+=.004*Math.sin(t*TAU);p.chest[0]=.008*s;p.head[1]=.035*s;return p;
  }
  if(id==='run'||id==='walk'){
    const run=id==='run',stride=run?.33:.225,lift=run?.16:.075;
    p.hips=[.008*s,-(run?.025:.012)+.018*Math.cos(t*TAU*2),0];p.spine=[run?.13:.035,0,0];p.chest=[0,-s*(run?.12:.05),0];p.head=[-(run?.055:.015),s*.025,0];
    for(const [key,sign] of [['left',1],['right',-1]]){
      const wave=s*sign,angle=(t+(sign===1?0:.5))%1;
      p[key+'Foot']=[sign*m.footX,m.ankleY+Math.max(0,wave)*lift,wave*stride];
      p[key+'FootRotation']=[-.24*Math.max(0,wave)+.18*Math.max(0,-wave),sign*.035,0];
      p[key+'Support']=wave<0?1:0;
      p[key].wrist=[sign*h*.17,h*(run?.62:.55)+Math.max(0,-wave)*.05,-wave*(run?.28:.14)+.09];
      p[key].fingers=[0,-.7,.7];p[key].normal=[-sign,.15,.3];
    }
    return p;
  }
  if(id==='decelerate'){
    const brake=pulse(t,.0,.24,.60,1),settle=ramp(t,.6,1);
    p.hips=[0,-.11*brake,.17*brake];p.spine=[-.17*brake,0,0];p.chest=[0,.08*brake,0];
    p.leftFoot=[m.footX,m.ankleY,.33*brake];p.rightFoot=[-m.footX,m.ankleY,-.18*brake];
    p.left.wrist=[.20*h,.58*h,.26*brake];p.right.wrist=[-.21*h,.54*h,-.10*brake];return p;
  }
  if(id==='pivot'){
    const yaw=.42*Math.sin(t*TAU);
    p.hips=[0,-.07,0];p.hipsRotation=[0,yaw*.55,0];p.chest=[0,yaw*.6,0];p.head=[0,-yaw*.25,0];
    p.leftFoot=[m.footX,m.ankleY,.02];p.leftFootRotation=[0,yaw*.5,0];
    p.rightFoot=[-m.footX-.09*(1-c),m.ankleY+.04*Math.max(0,s),.16*s];p.rightSupport=Math.max(0,s)<.05?1:0;
    p.rightFootRotation=[0,yaw,0];p.left.wrist=[.24*h,.56*h,.24];p.right.wrist=[-.23*h,.55*h,.25];return p;
  }
  return p;
}
function defensePose(id,t,m){
  const p=blankPose(m),{h}=m;
  p.hips[1]=-.105*h;p.spine[0]=.15;p.head[0]=-.06;
  p.leftFoot=[m.footX+.07,m.ankleY,0];p.rightFoot=[-m.footX-.07,m.ankleY,0];
  p.left.wrist=[.30*h,.63*h,.27];p.right.wrist=[-.30*h,.63*h,.27];
  p.left.fingers=[1,.1,.4];p.right.fingers=[-1,.1,.4];
  if(id==='defense_shuffle'){
    const s=Math.sin(t*TAU),s2=Math.sin(t*TAU*2);
    p.hips[0]=.13*s;p.hips[1]+=.018*Math.abs(s2);p.chest[1]=-.04*s;
    p.leftFoot[0]+=.13*s;p.rightFoot[0]+=.13*s;
    p.leftFoot[1]+=.055*Math.max(0,s2);p.rightFoot[1]+=.055*Math.max(0,-s2);
    p.leftSupport=s2<=0?1:0;p.rightSupport=s2>=0?1:0;
  }else if(id==='steal'){
    const reach=pulse(t,.06,.42,.48,.88);
    p.hips[0]=-.10*reach;p.hips[2]=.07*reach;p.chest[1]=-.24*reach;p.spine[0]+=.09*reach;
    p.right.wrist=lerp3(p.right.wrist,[-.23*h,.38*h,.64],reach);
    p.right.normal=[0,-1,0];p.right.fingers=[.05,-.1,1];p.left.wrist=[.28*h,.68*h,.18];
    p.rightFoot[2]=.18*reach;
  }else if(id==='block'){
    const jump=arc(t,.24,.84,.43),reach=pulse(t,.14,.45,.65,.92);
    p.hips[1]=-.13*(1-reach)+jump;p.spine[0]=.03;
    p.right.wrist=[-.12*h,.66*h+.39*h*reach+jump,.14+.06*reach];
    p.left.wrist=[.26*h,.65*h+.25*h*reach+jump,.12];
    p.right.fingers=[0,1,.05];p.left.fingers=[.15,1,0];p.right.normal=p.left.normal=[0,0,1];
    p.leftFoot[1]+=jump;p.rightFoot[1]+=jump+.08*Math.sin(Math.PI*ramp(t,.24,.84));
    p.leftSupport=p.rightSupport=t>.24&&t<.84?0:1;
  }
  return p;
}
function otherPose(id,t,m){
  const p=blankPose(m),{h}=m;
  if(id==='idle_hold'){
    hold(p,m);p.hips[1]=-.025+.003*Math.sin(t*TAU);p.spine[0]=.025;p.head[0]=.04;p.ball[1]+=.003*Math.sin(t*TAU);return p;
  }
  if(id==='euro_step'){
    hold(p,m);const left=pulse(t,.03,.22,.35,.56),right=pulse(t,.30,.52,.73,.94),gather=ramp(t,.62,.9);
    p.hips=[.17*left-.16*right,-.10+.08*Math.sin(Math.PI*gather),.22*pulse(t,.08,.50,.84,1)];
    p.chest=[0,-.18*left+.21*right,0];p.spine[0]=.11;p.head[1]=-.08*left+.08*right;
    p.ball=[.16*left-.15*right,.59*h+.10*gather,.34];
    p.leftFoot=[m.footX+.16*left,m.ankleY+.09*pulse(t,.28,.4,.49,.59),.13*left-.13*right];
    p.rightFoot=[-m.footX-.15*right,m.ankleY+.11*pulse(t,.08,.15,.24,.31),-.11*left+.18*right];
    p.leftSupport=t>.28&&t<.59?0:1;p.rightSupport=t>.08&&t<.31?0:1;
    return p;
  }
  if(id==='rebound'){
    const jump=arc(t,.22,.78,.37),catchTime=.43,gather=ramp(t,.48,.88),reach=ramp(t,.12,.4)*(1-gather);
    p.hips[1]=-.10*pulse(t,.02,.13,.21,.34)+jump;p.spine[0]=.02;
    p.ball=[.015,mix(.96*h+jump,.62*h,gather),.25+.08*gather];p.ballVisible=1;
    if(t<catchTime){const s=(catchTime-t)*CATALOG.rebound.duration;p.ball[1]=.96*h+arc(catchTime,.22,.78,.37)+2.7*s;}
    p.left.contact=p.right.contact=ramp(t,.415,.445);p.left.offset=[1,0,0];p.right.offset=[-1,0,0];
    p.left.fingers=p.right.fingers=[0,.3,1];
    p.left.wrist=[.13*h,(.70+.26*reach)*h+jump,.26];p.right.wrist=[-.13*h,(.70+.26*reach)*h+jump,.26];
    p.left.normal=[-1,0,0];p.right.normal=[1,0,0];
    p.leftFoot[1]+=jump;p.rightFoot[1]+=jump;p.leftSupport=p.rightSupport=t>.22&&t<.78?0:1;
    return p;
  }
  if(id==='celebrate'){
    const raise=pulse(t,.04,.33,.69,.98),bounce=.055*Math.sin(Math.PI*ramp(t,.22,.65));
    p.hips[1]=bounce;p.chest[1]=.10*Math.sin(t*TAU);p.head[0]=-.09*raise;
    p.left.wrist=[.17*h,.55*h+.40*h*raise,.02];p.right.wrist=[-.18*h,.55*h+.36*h*raise,.06];
    p.left.fingers=[0,1,0];p.right.fingers=[0,.7,.4];p.leftFoot[1]+=bounce;p.rightFoot[1]+=bounce;
    p.leftSupport=p.rightSupport=t>.22&&t<.65?0:1;return p;
  }
  if(id==='fall'){
    const down=ramp(t,.12,.43),rest=1-ramp(t,.62,.98),a=down*rest;
    p.hips=[-.15*a,-(m.hipsY-.20)*a,.02*a];p.hipsRotation=[.10*a,0,1.28*a];p.spine=[.12*a,0,.10*a];p.chest=[.07*a,0,0];p.head=[-.08*a,0,-.06*a];
    p.leftFoot=lerp3(p.leftFoot,[.33,.12,-.12],a);p.rightFoot=lerp3(p.rightFoot,[.65,.13,.12],a);
    p.left.wrist=lerp3(p.left.wrist,[-.36,.11,.24],a);p.right.wrist=lerp3(p.right.wrist,[-.44,.10,.16],a);
    p.left.normal=p.right.normal=[0,-1,0];p.left.fingers=[0,0,1];p.right.fingers=[0,0,1];
    p.leftSupport=p.rightSupport=a>.05?0:1;return p;
  }
  if(id==='referee_signal'){
    const raised=pulse(t,.05,.32,.66,.94);
    p.right.wrist=[-.13*h,.55*h+.45*h*raised,.06];p.right.normal=[0,0,1];p.right.fingers=[0,1,0];
    p.left.wrist=[.20*h,.55*h,.18];p.head[1]=.1*Math.sin(t*Math.PI);return p;
  }
  return p;
}

export function sampleMotion(id,phase,measurements){
  if(!CATALOG[id])throw new Error('Unknown basketball motion: '+id);
  const m=measurements,t=clamp(phase);
  if(id.startsWith('dribble_'))return dribblePose(id,t===1?0:t,m);
  if(id.startsWith('shot_'))return shotPose(id,t,m);
  if(id.startsWith('dunk_'))return dunkPose(id,t,m);
  if(id==='layup')return layupPose(t,m);
  if(['idle','run','walk','decelerate','pivot'].includes(id))return locomotion(id,t===1&&CATALOG[id].loop?0:t,m);
  if(['defense_shuffle','steal','block'].includes(id))return defensePose(id,t===1&&CATALOG[id].loop?0:t,m);
  return otherPose(id,t===1&&CATALOG[id].loop?0:t,m);
}

function quaternionBasis(fingers,normal){
  const f=V(normalized(fingers)),n=V(normalized(normal));
  f.addScaledVector(n,-f.dot(n));if(f.lengthSq()<1e-8)f.set(0,0,1).addScaledVector(n,-n.z);
  f.normalize();const side=new THREE.Vector3().crossVectors(f,n).normalize();
  return Q().setFromRotationMatrix(new THREE.Matrix4().makeBasis(side,f,n));
}
function handFrame(hand,root,profile,side,h){
  const key=side==='left'?'LeftHand':'RightHand';
  const supplied=profile?.palm?.[key]||profile?.palms?.[key]||profile?.palm?.[side]||profile?.palms?.[side];
  return {
    center:V(supplied?.palmPoint||supplied?.center||supplied?.localCenter||[0,-.040*h,.012]),
    normal:V(supplied?.palmNormal||supplied?.normal||[0,0,1]).normalize(),
    fingers:V(supplied?.fingers||supplied?.fingerDirection||[0,-1,0]).normalize(),
    worldBind:hand.getWorldQuaternion(Q()),
  };
}

/**
 * Construct one controller per character. Transform the model in an outer Group.
 * A supplied ball must share the model's parent, or can live elsewhere in scene;
 * the controller converts its centre/quaternion through that parent correctly.
 */
export function createMotionController(root,{ball=null,profile={},id='idle_hold',transitionSeconds=.34}={}){
  root.updateWorldMatrix(true,true);
  const bones=Object.fromEntries(BONE_NAMES.map(name=>[name,root.getObjectByName(name)]));
  const absent=BONE_NAMES.filter(n=>!bones[n]);if(absent.length)throw new Error('Missing canonical basketball joints: '+absent.join(', '));
  const bind=Object.fromEntries(BONE_NAMES.map(n=>[n,{position:bones[n].position.clone(),quaternion:bones[n].quaternion.clone(),scale:bones[n].scale.clone()}]));
  const toModel=o=>root.worldToLocal(o.getWorldPosition(new THREE.Vector3()));
  const restModel=Object.fromEntries(BONE_NAMES.map(n=>[n,toModel(bones[n])]));
  const suppliedHeight=Number(profile.heightMeters||profile.height);
  const h=suppliedHeight>1?suppliedHeight:Math.max(1.6,restModel.Head.y+.17);
  const m={h,hipsY:restModel.Hips.y,shoulderY:(restModel.LeftArm.y+restModel.RightArm.y)/2,
    ankleY:(restModel.LeftFoot.y+restModel.RightFoot.y)/2,
    footX:(Math.abs(restModel.LeftFoot.x)+Math.abs(restModel.RightFoot.x))/2,
    armReach:restModel.RightArm.distanceTo(restModel.RightForeArm)+restModel.RightForeArm.distanceTo(restModel.RightHand),ballRadius:.12};
  const handFrames={left:handFrame(bones.LeftHand,root,profile,'left',h),right:handFrame(bones.RightHand,root,profile,'right',h)};
  const restFootQ={left:bones.LeftFoot.getWorldQuaternion(Q()),right:bones.RightFoot.getWorldQuaternion(Q())};
  const chainLengths={};for(const [key,names] of [['left',['LeftArm','LeftForeArm','LeftHand']],['right',['RightArm','RightForeArm','RightHand']],['leftLeg',['LeftUpLeg','LeftLeg','LeftFoot']],['rightLeg',['RightUpLeg','RightLeg','RightFoot']]])chainLengths[key]=restModel[names[0]].distanceTo(restModel[names[1]])+restModel[names[1]].distanceTo(restModel[names[2]]);
  let action=CATALOG[id]?id:'idle_hold',time=0,frame=0,transition=null,pending=null,displayed=sampleMotion(action,0,m),previousBall=V(displayed.ball),ballVelocity=new THREE.Vector3(),lastDt=0,lastDiagnostics={};
  const maxReach={left:0,right:0,leftLeg:0,rightLeg:0};
  function modelQ(){return root.getWorldQuaternion(Q());}
  function targetWorld(a){return root.localToWorld(V(a));}
  function setWorldQuaternion(bone,q){bone.parent.updateWorldMatrix(true,false);bone.quaternion.copy(bone.parent.getWorldQuaternion(Q()).invert().multiply(q));bone.updateWorldMatrix(false,true);}
  function rotation(name,euler){bones[name].quaternion.copy(bind[name].quaternion).multiply(Q().setFromEuler(new THREE.Euler(...euler,'XYZ')));bones[name].updateWorldMatrix(false,true);}
  function aim(bone,child,point){
    const origin=bone.getWorldPosition(new THREE.Vector3()),old=child.getWorldPosition(new THREE.Vector3()).sub(origin).normalize(),next=point.clone().sub(origin).normalize();
    if(next.lengthSq()<.5)return;
    const world=Q().setFromUnitVectors(old,next).multiply(bone.getWorldQuaternion(Q()));setWorldQuaternion(bone,world);
  }
  function chain(upperName,lowerName,endName,target,pole,key){
    const upper=bones[upperName],lower=bones[lowerName],end=bones[endName],a=upper.getWorldPosition(new THREE.Vector3());
    const l1=a.distanceTo(lower.getWorldPosition(new THREE.Vector3())),l2=lower.getWorldPosition(new THREE.Vector3()).distanceTo(end.getWorldPosition(new THREE.Vector3()));
    const t=targetWorld(target),axis=t.clone().sub(a),requested=axis.length(),len=clamp(requested,.005,l1+l2-.00005);axis.normalize();
    const poleWorld=targetWorld(pole).sub(a),perp=poleWorld.addScaledVector(axis,-poleWorld.dot(axis));
    if(perp.lengthSq()<1e-8)perp.set(0,0,1).addScaledVector(axis,-axis.z);perp.normalize();
    const along=clamp((l1*l1-l2*l2+len*len)/(2*len),-l1,l1),height=Math.sqrt(Math.max(0,l1*l1-along*along));
    const elbow=a.clone().addScaledVector(axis,along).addScaledVector(perp,height),reachable=a.clone().addScaledVector(axis,len);
    aim(upper,lower,elbow);aim(lower,end,reachable);
    maxReach[key]=Math.max(0,requested-(l1+l2));
  }
  function handTarget(key,p){
    const hand=p[key],f=handFrames[key],sign=key==='left'?1:-1,contact=clamp(hand.contact),offset=V(normalized(hand.offset));
    const desiredNormal=contact>.001?offset.clone().negate():V(hand.normal);
    const contactQ=quaternionBasis(hand.fingers,desiredNormal.toArray()).multiply(quaternionBasis(f.fingers.toArray(),f.normal.toArray()).invert());
    const freeQ=quaternionBasis(hand.fingers,hand.normal).multiply(quaternionBasis(f.fingers.toArray(),f.normal.toArray()).invert());
    const desiredQ=freeQ.slerp(contactQ,contact);
    const palmOffset=f.center.clone().applyQuaternion(desiredQ);
    const center=V(p.ball).addScaledVector(offset,m.ballRadius),contactWrist=center.sub(palmOffset);
    const wrist=V(hand.wrist).lerp(contactWrist,contact);
    return {wrist:wrist.toArray(),rotation:desiredQ,contact,offset:offset.toArray(),finger:hand.fingers,sign};
  }
  function apply(p){
    for(const name of BONE_NAMES){bones[name].position.copy(bind[name].position);bones[name].quaternion.copy(bind[name].quaternion);bones[name].scale.copy(bind[name].scale);}
    root.updateWorldMatrix(true,true);
    const setHips=()=>{const hipsTarget=targetWorld(add3(restModel.Hips.toArray(),p.hips));bones.Hips.position.copy(bones.Hips.parent.worldToLocal(hipsTarget));bones.Hips.updateWorldMatrix(false,true);};setHips();
    rotation('Hips',p.hipsRotation);rotation('Spine',p.spine);rotation('Chest',p.chest);rotation('Neck',p.neck);rotation('Head',p.head);
    // Reach adaptation uses the measured limb lengths of each position. Lower
    // the pelvis for a planted long step instead of stretching the shin or
    // allowing a supporting sole to rise. Airborne targets remain free.
    let lower=0;
    for(const [key,name]of [['left','LeftUpLeg'],['right','RightUpLeg']])if(p[key+'Support']>.99){
      const hip=toModel(bones[name]),foot=V(p[key+'Foot']),dx=hip.x-foot.x,dz=hip.z-foot.z,L=chainLengths[key+'Leg']*.998;
      const available=Math.sqrt(Math.max(.0001,L*L-dx*dx-dz*dz));lower=Math.max(lower,hip.y-foot.y-available);
    }
    if(lower>0){p.hips[1]-=Math.min(lower,.18*h);setHips();}
    // A few millimetres of measured-proportion adaptation keep a small guard's
    // shooting pocket reachable, while the ball and both palms move together.
    for(let iteration=0;iteration<3;iteration++)for(const [key,name]of [['left','LeftArm'],['right','RightArm']])if(p[key].contact>.5){
      const a=handTarget(key,p),shoulder=toModel(bones[name]),delta=V(a.wrist).sub(shoulder),distance=delta.length(),max=chainLengths[key]*.997;
      if(distance>max){const strength=smooth((p[key].contact-.5)*2);delta.multiplyScalar((distance-max)/distance*strength);p.ball=V(p.ball).sub(delta).toArray();}
    }
    const left=handTarget('left',p),right=handTarget('right',p);
    for(const [key,name]of [['left','LeftUpLeg'],['right','RightUpLeg']])if(p[key+'Support']<.99){
      const hip=toModel(bones[name]),delta=V(p[key+'Foot']).sub(hip),reach=chainLengths[key+'Leg']*.985;
      if(delta.length()>reach)p[key+'Foot']=hip.add(delta.setLength(reach)).toArray();
    }
    chain('LeftUpLeg','LeftLeg','LeftFoot',p.leftFoot,[m.footX+.04,m.hipsY*.5,.75],'leftLeg');
    chain('RightUpLeg','RightLeg','RightFoot',p.rightFoot,[-m.footX-.04,m.hipsY*.5,.75],'rightLeg');
    const mq=modelQ();
    for(const [key,name] of [['left','LeftFoot'],['right','RightFoot']]){
      const angles=[...p[key+'FootRotation']];if(p[key+'Support']>.99){angles[0]=0;angles[2]=0;}
      const delta=Q().setFromEuler(new THREE.Euler(...angles,'XYZ'));
      const restLocal=mq.clone().invert().multiply(restFootQ[key]);setWorldQuaternion(bones[name],mq.clone().multiply(delta).multiply(restLocal));
    }
    for(const [key,a,names] of [['left',left,['LeftArm','LeftForeArm','LeftHand']],['right',right,['RightArm','RightForeArm','RightHand']]]){
      const arm=restModel[names[0]],pole=[a.sign*(.48*h),arm.y-.25,.14];
      if(a.contact<.99){const shoulder=toModel(bones[names[0]]),delta=V(a.wrist).sub(shoulder),reach=chainLengths[key]*.975;if(delta.length()>reach)a.wrist=shoulder.add(delta.setLength(reach)).toArray();}
      chain(...names,a.wrist,pole,key);setWorldQuaternion(bones[names[2]],mq.clone().multiply(a.rotation));
    }
    root.updateWorldMatrix(true,true);
    if(ball){
      ball.visible=p.ballVisible>.05;
      const world=targetWorld(p.ball);ball.position.copy(ball.parent?ball.parent.worldToLocal(world):world);
      const rotation=mq.clone().multiply(Q().setFromEuler(new THREE.Euler(...p.ballRotation,'XYZ')));
      ball.quaternion.copy(ball.parent?ball.parent.getWorldQuaternion(Q()).invert().multiply(rotation):rotation);
      ball.updateWorldMatrix(false,true);
    }
    const contacts=[];let error=0;
    for(const [key,name] of [['left','LeftHand'],['right','RightHand']]){
      if(p[key].contact<.99)continue;
      const f=handFrames[key],palm=f.center.clone().applyMatrix4(bones[name].matrixWorld),center=targetWorld(p.ball),dist=palm.distanceTo(center),e=Math.abs(dist-m.ballRadius);
      error=Math.max(error,e);contacts.push({effector:name,palm:root.worldToLocal(palm).toArray(),errorMeters:e});
    }
    const feet={};for(const [key,name] of [['left','LeftFoot'],['right','RightFoot']]){
      const actual=toModel(bones[name]);feet[key]={support:p[key+'Support']>.99,target:p[key+'Foot'],position:actual.toArray(),errorMeters:actual.distanceTo(V(p[key+'Foot']))};
    }
    lastDiagnostics={action,time,phase:getPhase(),transition:transition?{from:transition.from,to:action,progress:clamp(transition.elapsed/transition.duration)}:pending?{from:action,to:pending.id,waitingForCatch:true}:null,
      contact:contacts,handContactErrorMeters:error,footErrors:feet,maxReach:{...maxReach},ballPosition:[...p.ball],ballVisible:p.ballVisible>.05,frame,rootMotion:false};
  }
  function getPhase(){const a=CATALOG[action];return a.loop?(time/a.duration)%1:clamp(time/a.duration);}
  function begin(next,duration){
    const before=copy(displayed),beforeVelocity=ballVelocity.toArray();
    transition={from:action,source:before,velocity:beforeVelocity,elapsed:0,duration};action=next;time=0;pending=null;
  }
  function render(dt=0){
    const target=sampleMotion(action,getPhase(),m);
    if(transition){
      const u=clamp(transition.elapsed/transition.duration),s=smooth(u),source=transition.source;
      displayed=blend(source,target,s);
      // Hermite endpoint derivatives preserve the displayed ball velocity at
      // interrupted transitions; post-blend wrist IK keeps any full contact.
      const u2=u*u,u3=u2*u,dh=transition.duration;
      displayed.ball=source.ball.map((x,i)=>(2*u3-3*u2+1)*x+(u3-2*u2+u)*dh*transition.velocity[i]+(-2*u3+3*u2)*target.ball[i]);
      displayed.ball[1]=Math.max(m.ballRadius,displayed.ball[1]);
      if(u>=1)transition=null;
    }else displayed=target;
    if(dt>1e-6){ballVelocity.copy(V(displayed.ball).sub(previousBall).multiplyScalar(1/dt));lastDt=dt;}
    previousBall.copy(V(displayed.ball));frame++;apply(displayed);
  }
  const controller={
    setAction(next,{immediate=false,blendSeconds=transitionSeconds}={}){
      if(!CATALOG[next])throw new Error('Unknown basketball motion: '+next);
      if(immediate){action=next;time=0;transition=pending=null;ballVelocity.set(0,0,0);render();return controller;}
      if(next===action&&!pending&&!transition)return controller;
      // A live dribble is gathered at the next upper catch. It cannot be
      // physically held while its centre is still at the floor.
      if(next==='idle_hold'&&action.startsWith('dribble_')&&!transition){pending={id:next,duration:Math.max(.28,blendSeconds)};return controller;}
      begin(next,Math.max(.08,blendSeconds));return controller;
    },
    update(dt){
      dt=clamp(Number(dt)||0,0,.10);time+=dt;
      if(pending){
        const a=CATALOG[action],phase=getPhase(),u=(action==='dribble_crossover'||action==='dribble_between_legs')?(phase*2)%1:phase;
        if(u>.975||u<.025)begin(pending.id,pending.duration);
      }
      if(transition)transition.elapsed+=dt;render(dt);return controller;
    },
    seek(phase){time=clamp(Number(phase)||0)*CATALOG[action].duration;transition=pending=null;ballVelocity.set(0,0,0);render();return controller;},
    getDiagnostics(){return copy(lastDiagnostics);},
    snapshot(){return {action,time,phase:getPhase(),measurements:{...m},pose:copy(displayed),bones:Object.fromEntries(BONE_NAMES.map(n=>[n,{position:bones[n].position.toArray(),quaternion:bones[n].quaternion.toArray()}])),...controller.getDiagnostics()};},
    get action(){return action;},get duration(){return CATALOG[action].duration;},get measurements(){return {...m};},
    dispose(){for(const n of BONE_NAMES){bones[n].position.copy(bind[n].position);bones[n].quaternion.copy(bind[n].quaternion);bones[n].scale.copy(bind[n].scale);}root.updateWorldMatrix(true,true);},
  };
  render();return controller;
}
