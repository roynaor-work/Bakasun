#!/usr/bin/env node
// Independent vertex-space audit of the actual decoded, posed meshes in Three r160.
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const require=createRequire('/tmp/hoops-v7-tools/package.json');
const {chromium}=require('playwright');
const hz=Math.max(12,Number(process.argv[process.argv.indexOf('--hz')+1])||30);
const files=(await fs.readdir(path.join(root,'models'))).filter(n=>n.endsWith('.glb'));
async function hashes(){return Promise.all(files.map(async name=>({file:'models/'+name,sha256:createHash('sha256').update(await fs.readFile(path.join(root,'models',name))).digest('hex')})));}
const inputs=await hashes();
const mime={'.html':'text/html','.css':'text/css','.mjs':'text/javascript','.js':'text/javascript','.json':'application/json','.wasm':'application/wasm','.glb':'model/gltf-binary'};
const server=http.createServer(async(req,res)=>{try{const url=decodeURIComponent(new URL(req.url,'http://localhost').pathname);if(url==='/favicon.ico'){res.writeHead(204);res.end();return;}const p=path.resolve(root,'.'+(url==='/'?'/index.html':url));if(!p.startsWith(root+path.sep))throw Error('path');const b=await fs.readFile(p);res.writeHead(200,{'Content-Type':mime[path.extname(p)]||'application/octet-stream'});res.end(b);}catch{res.writeHead(404);res.end();}});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin=`http://127.0.0.1:${server.address().port}`;
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:390,height:844}}),errors=[],externalRequests=[];
page.on('pageerror',error=>errors.push(String(error)));
await page.route('**/*',route=>{const u=route.request().url();if(u.startsWith(origin)||u.startsWith('blob:')||u.startsWith('data:'))return route.continue();externalRequests.push(u);return route.abort();});
let result;
try{
 await page.goto(origin+'/index.html?capture=1');
 await page.waitForFunction(()=>!!window.__hoopsLab,null,{timeout:120000});
 await page.evaluate(async()=>{await window.__hoopsLab.ready;window.__hoopsLab.pause(true);window.__hoopsLab.setView('near');});
 result=await page.evaluate(async({hz})=>{
  const THREE=await import('./vendor/three.module.js'),api=window.__hoopsLab;
  const v=new THREE.Vector3(),center=new THREE.Vector3(),models=[],records=[];
  for(const actor of api.actors){
   api.selectRole(actor.id);
   for(let level=0;level<actor.roots.length;level++){
    const root=actor.roots[level],parts=[];
    root.updateWorldMatrix(true,true);
    root.traverse(mesh=>{
     if(!mesh.isSkinnedMesh)return;
     const skeleton=mesh.skeleton,position=mesh.geometry.attributes.position,joints=mesh.geometry.attributes.skinIndex,weights=mesh.geometry.attributes.skinWeight;
     const names=skeleton.bones.map(b=>b.name),hand={left:[],right:[]},feet={left:[],right:[]};
     for(let i=0;i<position.count;i++){
      const row=[joints.getX(i),joints.getY(i),joints.getZ(i),joints.getW(i)],w=[weights.getX(i),weights.getY(i),weights.getZ(i),weights.getW(i)];
      for(const [side,prefix]of[['left','Left'],['right','Right']]){
       if(row.reduce((n,j,k)=>n+(names[j]===prefix+'Hand'?w[k]:0),0)>.50)hand[side].push(i);
       if(row.reduce((n,j,k)=>n+(names[j]===prefix+'Foot'?w[k]:0),0)>.50)feet[side].push(i);
      }
     }
     parts.push({mesh,hand,feet,all:Array.from({length:position.count},(_,i)=>i)});
    });
    models.push({actor,level,root,parts});
   }
  }
  for(const model of models){
   const {actor,root,parts,level}=model;
   api.selectRole(actor.id);api.setLOD(level?'low':'high');
   for(const action of api.actions){
    const controller=actor.controller;controller.setAction(action.id,{immediate:true});
    const steps=Math.max(2,Math.ceil(action.duration*hz));
    const row={role:actor.id,lod:level,action:action.id,samples:steps+1,handContacts:0,
     minFootVertexY:Infinity,maxSupportedSoleGap:0,maxHandPenetration:0,maxNearestHandSurfaceGap:0,
     worstFloorPhase:null,worstHandPhase:null,nonFiniteVertices:0,fallBodyMinimumY:null};
    for(let sample=0;sample<=steps;sample++){
     const phase=sample/steps;controller.seek(phase);root.updateWorldMatrix(true,true);
     const diag=controller.getDiagnostics();
     for(const part of parts)part.mesh.skeleton.update();
     for(const side of ['left','right']){
      let sole=Infinity;
      for(const part of parts)for(const index of part.feet[side]){
       part.mesh.getVertexPosition(index,v).applyMatrix4(part.mesh.matrixWorld);
       // Actors are laid out at y=0; world transform is included independently.
       if(!Number.isFinite(v.y))row.nonFiniteVertices++;else sole=Math.min(sole,v.y);
      }
      if(sole<row.minFootVertexY){row.minFootVertexY=sole;row.worstFloorPhase=phase;}
      if(diag.footErrors?.[side]?.support)row.maxSupportedSoleGap=Math.max(row.maxSupportedSoleGap,sole);
      const contact=diag.contact?.some(c=>c.effector===(side==='left'?'LeftHand':'RightHand'));
      if(!contact||!diag.ballVisible)continue;
      center.fromArray(diag.ballPosition);actor.root.localToWorld(center);
      let nearest=Infinity,penetration=0,vertices=0;
      for(const part of parts)for(const index of part.hand[side]){
       part.mesh.getVertexPosition(index,v).applyMatrix4(part.mesh.matrixWorld);
       const distance=v.distanceTo(center);if(!Number.isFinite(distance)){row.nonFiniteVertices++;continue;}
       vertices++;nearest=Math.min(nearest,Math.abs(distance-.12));penetration=Math.max(penetration,.12-distance);
      }
      if(vertices){row.handContacts++;if(penetration>row.maxHandPenetration){row.maxHandPenetration=penetration;row.worstHandPhase=phase;}row.maxNearestHandSurfaceGap=Math.max(row.maxNearestHandSurfaceGap,nearest);}
     }
     if(action.id==='fall'){
      let bodyY=Infinity;
      for(const part of parts)for(const index of part.all){part.mesh.getVertexPosition(index,v).applyMatrix4(part.mesh.matrixWorld);bodyY=Math.min(bodyY,v.y);}
      row.fallBodyMinimumY=row.fallBodyMinimumY===null?bodyY:Math.min(row.fallBodyMinimumY,bodyY);
     }
    }
    row.floorPass=row.minFootVertexY>=-.010&&(row.fallBodyMinimumY===null||row.fallBodyMinimumY>=-.015);
    row.handPass=row.maxHandPenetration<=.020&&row.maxNearestHandSurfaceGap<=.020;
    row.pass=row.floorPass&&row.handPass&&row.nonFiniteVertices===0;
    records.push(row);
   }
  }
  return{sampleHz:hz,records,totals:{poseSamples:records.reduce((n,r)=>n+r.samples,0),handContacts:records.reduce((n,r)=>n+r.handContacts,0)},
   thresholds:{floorPenetrationMeters:.010,fallBodyPenetrationMeters:.015,handPenetrationMeters:.020,nearestHandVertexSurfaceGapMeters:.020},
   scope:'Actual decoded Three.js skinned/morphed vertices, not virtual IK palm markers. Foot-dominant vertices sampled for all actions; all vertices additionally sampled for fall. Hand-dominant vertices sampled only during declared full contact. This measures vertices, not continuous triangle/ball collision or physical simulation.',
   pass:records.every(r=>r.pass)};
 },{hz});
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
const after=await hashes(),changed=inputs.filter(a=>!after.some(b=>a.file===b.file&&a.sha256===b.sha256));
const report={schemaVersion:1,generatedAtUtc:new Date().toISOString(),inputs,changedDuringAudit:changed,errors,externalRequests,...result,pass:result?.pass&&changed.length===0&&errors.length===0&&externalRequests.length===0};
await fs.writeFile(path.join(root,'verification/skin-validation.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({pass:report.pass,totals:report.totals,failures:report.records?.filter(r=>!r.pass),errors,changedDuringAudit:changed}));
if(!report.pass)process.exitCode=1;
