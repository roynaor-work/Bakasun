/** Continue the connected source trouser yoke with loose tapered legs.
 * The first ring shares the exact source hem; rings follow the canonical leg
 * chain and blend weights through the knee rather than copying skin tights. */
export function extendTrouserLeg({THREE,source,world,side,boneNames,empty,addVertex,uvRect}){
 const out=empty(),sign=side==='Left'?1:-1,keys=[],points=new Map(),edges=new Map();
 for(let i=0;i<source.pos.length/3;i++){const p=source.pos.slice(i*3,i*3+3),key=p.map(v=>Math.round(v*100000)).join(',');keys.push(key);if(!points.has(key))points.set(key,{p,id:i});}
 for(let i=0;i<source.index.length;i+=3)for(let k=0;k<3;k++){const a=keys[source.index[i+k]],b=keys[source.index[i+(k+1)%3]],key=[a,b].sort().join('|');if(edges.has(key))edges.get(key).count++;else edges.set(key,{a,b,count:1});}
 const selected=new Set();for(const e of edges.values())if(e.count===1)for(const key of [e.a,e.b]){const p=points.get(key).p;if(sign*p[0]>.015&&p[1]<world.Hips[1]-.12)selected.add(key);}
 const ring=[...selected].map(k=>points.get(k));if(ring.length<8)throw new Error('Cannot locate '+side+' trouser hem');
 const center=ring.reduce((v,q)=>v.add(new THREE.Vector3(...q.p)),new THREE.Vector3()).multiplyScalar(1/ring.length);ring.sort((a,b)=>Math.atan2(a.p[2]-center.z,a.p[0]-center.x)-Math.atan2(b.p[2]-center.z,b.p[0]-center.x));
 const ankle=new THREE.Vector3(...world[side+'Foot']),knee=new THREE.Vector3(...world[side+'Leg']),hip=new THREE.Vector3(...world[side+'UpLeg']),endY=ankle.y+.012,rows=14,count=ring.length;
 const atY=y=>{const a=y>=knee.y?hip:knee,b=y>=knee.y?knee:ankle,t=Math.max(0,Math.min(1,(y-a.y)/(b.y-a.y)));return a.clone().lerp(b,t);};
 for(let row=0;row<=rows;row++){const t=row/rows,blend=Math.min(1,t*5),scale=1-.24*t;for(const q of ring){const y=q.p[1]*(1-t)+endY*t,axis=atY(y),cx=center.x*(1-t)+axis.x*t,cz=center.z*(1-t)+axis.z*t,p=[cx+(q.p[0]-center.x)*scale,y,cz+(q.p[2]-center.z)*scale],n=new THREE.Vector3(q.p[0]-center.x,.012,q.p[2]-center.z).normalize();const ws=new Map();for(let k=0;k<4;k++){const j=source.joint[q.id*4+k],w=source.weight[q.id*4+k]*(1-blend);ws.set(j,(ws.get(j)||0)+w);}const leg=Math.max(0,Math.min(1,(knee.y+.10-y)/.20));for(const [name,w]of [[side+'UpLeg',1-leg],[side+'Leg',leg]]){const j=boneNames.indexOf(name);ws.set(j,(ws.get(j)||0)+w*blend);}const weights=[...ws].filter(p=>p[1]>1e-6).sort((a,b)=>b[1]-a[1]).slice(0,4),sum=weights.reduce((s,p)=>s+p[1],0);addVertex(out,p,n.toArray(),uvRect(.5,.5,'solid'),weights.map(([j,w])=>[boneNames[j],w/sum]));}}
 for(let row=1;row<=rows;row++)for(let col=0;col<count;col++){const a=(row-1)*count+col,b=(row-1)*count+(col+1)%count,c=row*count+col,d=row*count+(col+1)%count;for(const ids of [[a,b,c],[b,d,c]]){const p=ids.map(i=>new THREE.Vector3(...out.pos.slice(i*3,i*3+3))),normal=p[1].clone().sub(p[0]).cross(p[2].clone().sub(p[0])),outward=new THREE.Vector3(...out.norm.slice(ids[0]*3,ids[0]*3+3));if(normal.dot(outward)<0)ids.reverse();out.index.push(...ids);}}
 return out;
}

/** Remove the original turned shorts cuffs before extending them as trousers. */
export function trimTrouserYoke(source,cutY,empty){
 const out=empty();
 const mix=(a,b,t)=>{const weights=new Map();for(const [v,m]of [[a,1-t],[b,t]])for(let k=0;k<4;k++)weights.set(v.j[k],(weights.get(v.j[k])||0)+v.w[k]*m);const ws=[...weights].sort((a,b)=>b[1]-a[1]).slice(0,4),sum=ws.reduce((v,p)=>v+p[1],0)||1;while(ws.length<4)ws.push([0,0]);const n=a.n.map((v,k)=>v+(b.n[k]-v)*t),l=Math.hypot(...n)||1;return{p:a.p.map((v,k)=>v+(b.p[k]-v)*t),n:n.map(v=>v/l),uv:a.uv.map((v,k)=>v+(b.uv[k]-v)*t),j:ws.map(p=>p[0]),w:ws.map(p=>p[1]/sum)};};
 for(let i=0;i<source.index.length;i+=3){const poly=source.index.slice(i,i+3).map(j=>({p:source.pos.slice(j*3,j*3+3),n:source.norm.slice(j*3,j*3+3),uv:source.uv.slice(j*2,j*2+2),j:source.joint.slice(j*4,j*4+4),w:source.weight.slice(j*4,j*4+4)})),clipped=[];for(let k=0;k<3;k++){const a=poly[k],b=poly[(k+1)%3],ia=a.p[1]>=cutY,ib=b.p[1]>=cutY;if(ia)clipped.push(a);if(ia!==ib)clipped.push(mix(a,b,(cutY-a.p[1])/(b.p[1]-a.p[1])));}if(clipped.length<3)continue;const first=out.pos.length/3;for(const v of clipped){out.pos.push(...v.p);out.norm.push(...v.n);out.uv.push(...v.uv);out.joint.push(...v.j);out.weight.push(...v.w);out.gripLeft.push(0,0,0);out.gripRight.push(0,0,0);}for(let k=1;k<clipped.length-1;k++)out.index.push(first,first+k,first+k+1);}
 Object.assign(source,out);return source;
}
