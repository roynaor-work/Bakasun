#!/usr/bin/env node
/** Bake the live, mesh-aware motion solver into the delivered GLBs.
 * Viewing needs no build. This authoring command needs the external tool prefix.
 * Default: validate staged files in /tmp only. Pass --write for the final bake.
 * node source/motion-export.mjs --modules /tmp/hoops-v7-tools [--only pg] [--write]
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const arg=(name,fallback)=>{const i=process.argv.indexOf(name);return i<0?fallback:process.argv[i+1];};
const require=createRequire(path.resolve(arg('--modules','/tmp/hoops-v7-tools'),'package.json'));
const {NodeIO}=require('@gltf-transform/core');
const {ALL_EXTENSIONS}=require('@gltf-transform/extensions');
const {prune,dedup,resample,sparse,draco}=require('@gltf-transform/functions');
const codec=require('draco3dgltf'),validator=require('gltf-validator'),{chromium}=require('playwright');
const sha=b=>createHash('sha256').update(b).digest('hex');
const ALL_IDS=['pg','sg','sf','pf','c','referee'];
const requested=arg('--only',null),ids=requested?requested.split(','):ALL_IDS;
if(ids.some(id=>!ALL_IDS.includes(id)))throw Error('Unknown --only profile');
const hz=Number(arg('--hz','30'));
if(!Number.isFinite(hz)||hz<30||hz>120)throw Error('--hz must be30..120');
const write=process.argv.includes('--write'),startedAtUTC=new Date().toISOString();
const stage=await fs.mkdtemp('/tmp/hoops-v7-baked-');
const sourceFiles=new Map(),inputHashes=[];
async function freeze(file){const bytes=await fs.readFile(path.join(root,file));sourceFiles.set('/'+file,bytes);inputHashes.push({file,bytes:bytes.length,sha256:sha(bytes)});return bytes;}
for(const file of ['source/motion.mjs','rig.json','model-authoring.json','vendor/three.module.js','vendor/GLTFLoader.js','vendor/DRACOLoader.js','vendor/BufferGeometryUtils.js','vendor/draco/draco_wasm_wrapper.js','vendor/draco/draco_decoder.wasm'])await freeze(file);
for(const id of ids)for(const suffix of ['', '-lod1'])await freeze(`models/${id}${suffix}.glb`);
const rig=JSON.parse(sourceFiles.get('/rig.json')),authoring=JSON.parse(sourceFiles.get('/model-authoring.json'));
const io=new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({'draco3d.decoder':await codec.createDecoderModule(),'draco3d.encoder':await codec.createEncoderModule()});
const html='<!doctype html><meta charset="utf-8"><title>Local motion bake</title><script type="importmap">{"imports":{"three":"/vendor/three.module.js"}}</script><script type="module">import * as THREE from "/vendor/three.module.js";import {GLTFLoader}from"/vendor/GLTFLoader.js";import{DRACOLoader}from"/vendor/DRACOLoader.js";import{ACTIONS,BONE_NAMES,createMotionController}from"/source/motion.mjs";const draco=new DRACOLoader();draco.setDecoderPath("/vendor/draco/");draco.setWorkerLimit(2);const loader=new GLTFLoader();loader.setDRACOLoader(draco);window.__bake={THREE,loader,draco,ACTIONS,BONE_NAMES,createMotionController,truth:new Map()};</script>';
sourceFiles.set('/bake.html',Buffer.from(html));
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.wasm':'application/wasm','.glb':'model/gltf-binary'};
const server=http.createServer((request,response)=>{const pathname=new URL(request.url,'http://localhost').pathname;if(pathname==='/favicon.ico'){response.writeHead(204);response.end();return;}const bytes=sourceFiles.get(pathname);if(!bytes){response.writeHead(404);response.end();return;}response.writeHead(200,{'Content-Type':mime[path.extname(pathname)]||'application/octet-stream','Cache-Control':'no-store'});response.end(bytes);});
await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
const origin=`http://127.0.0.1:${server.address().port}`;
const browser=await chromium.launch({executablePath:arg('--executable','/usr/bin/chromium'),headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const context=await browser.newContext(),page=await context.newPage(),browserErrors=[],externalRequests=[];
await context.route('**/*',route=>{const url=route.request().url();if(url.startsWith(origin)||url.startsWith('blob:')||url.startsWith('data:'))return route.continue();externalRequests.push(url);return route.abort();});
page.on('pageerror',error=>browserErrors.push(String(error)));
page.on('console',message=>{if(message.type()==='error')browserErrors.push(message.text());});
const assets=[],profileSummaries=[],staged=new Map();let fatalError=null;
function same(a,b,epsilon=1e-7){return a.length===b.length&&a.every((v,i)=>Math.abs(v-b[i])<=epsilon);}
function quaternionNormalize(q){const l=Math.hypot(...q);if(!Number.isFinite(l)||l<1e-6)throw Error('Non-finite/zero baked quaternion');return q.map(v=>v/l);}
function canonicalizeQuaternionTrack(values){for(let i=0;i<values.length;i+=4){const q=quaternionNormalize(values.slice(i,i+4));if(i&&q.reduce((s,v,k)=>s+v*values[i-4+k],0)<0)for(let k=0;k<4;k++)q[k]*=-1;values.splice(i,4,...q);}return values;}
function removeDraco(document){for(const extension of [...document.getRoot().listExtensionsUsed()])if(extension.extensionName==='KHR_draco_mesh_compression')extension.dispose();}
function validationSummary(report){return{errors:report.issues.numErrors,warnings:report.issues.numWarnings,infos:report.issues.numInfos,messages:report.issues.messages,truncated:report.issues.truncated};}
function bindRecords(document){const joints=document.getRoot().listSkins()[0].listJoints();return Object.fromEntries(joints.map(n=>[n.getName(),{translation:n.getTranslation(),rotation:n.getRotation(),scale:n.getScale()}]));}
function assertSharedBind(high,low,id){for(const [name,a]of Object.entries(high)){const b=low[name];if(!b||!same(a.translation,b.translation,1e-6)||!same(a.rotation,b.rotation,1e-6)||!same(a.scale,b.scale,1e-6))throw Error(`LOD bind differs: ${id}/${name}`);}}
async function bake(document,samples,id,lod){
 const g=document.getRoot(),buffer=g.listBuffers()[0]||document.createBuffer('Baked presentation motion');
 for(const animation of [...g.listAnimations()])animation.dispose();
 for(const node of [...g.listNodes()])if(node.getName()==='MotionBallAnchor')node.dispose();
 const scene=g.getDefaultScene()||g.listScenes()[0];
 const anchor=document.createNode('MotionBallAnchor').setExtras({presentationOnly:true,radiusMeters:.12,units:'meters',purpose:'Attach an unbranded basketball mesh. Position/rotation/scale are authored presentation only; scale zero means hidden. No ownership, score or physics is implied.'});scene.addChild(anchor);
 const boneNodes=Object.fromEntries(g.listSkins()[0].listJoints().map(n=>[n.getName(),n]));
 const meshNodes=g.listNodes().filter(n=>n.getMesh()&&n.getMesh().listPrimitives().some(p=>p.listTargets().length));
 // Accessor labels do not affect playback; omitting thousands of repeated
 // labels leaves more of the1.5MB budget for geometry and actual keyframes.
 const accessor=(name,type,array)=>document.createAccessor().setType(type).setArray(new Float32Array(array)).setBuffer(buffer);
 const clipStatistics=[];
 for(const clip of samples.clips){
  const animation=document.createAnimation(clip.id).setExtras({loop:clip.loop,durationSeconds:clip.duration,presentationOnly:true,rootMotion:false});
  const times=clip.frames.map(frame=>frame.t),input=accessor(clip.id+' times','SCALAR',times);
  let omittedBindChannels=0,constantPoseChannels=0,storedChannels=0;
  const channel=(node,targetPath,values,size,bindValue,interpolation='LINEAR')=>{
   if(targetPath==='rotation')canonicalizeQuaternionTrack(values);
   if(!values.every(Number.isFinite))throw Error(`Non-finite ${id}/${clip.id}/${node.getName()}/${targetPath}`);
   const first=values.slice(0,size),constant=values.every((v,i)=>Math.abs(v-first[i%size])<1e-8);
   const sameBind=bindValue&&same(first,bindValue,1e-7);
   if(constant&&sameBind){omittedBindChannels++;return;}
   const channelInput=constant?accessor(clip.id+' constant time','SCALAR',[0]):input;
   const output=accessor(`${clip.id} ${node.getName()} ${targetPath}`,targetPath==='weights'?'SCALAR':size===4?'VEC4':'VEC3',constant?first:values);
   const sampler=document.createAnimationSampler().setInput(channelInput).setOutput(output).setInterpolation(interpolation);
   animation.addSampler(sampler).addChannel(document.createAnimationChannel().setTargetNode(node).setTargetPath(targetPath).setSampler(sampler));storedChannels++;if(constant)constantPoseChannels++;
  };
  for(const [name,node]of Object.entries(boneNodes)){
   channel(node,'translation',clip.frames.flatMap(f=>f.bones[name].position),3,node.getTranslation());
   channel(node,'rotation',clip.frames.flatMap(f=>f.bones[name].quaternion),4,node.getRotation());
   channel(node,'scale',clip.frames.flatMap(f=>f.bones[name].scale),3,node.getScale());
  }
  for(const node of meshNodes){
   const names=node.getMesh().getExtras().targetNames||node.getMesh().listPrimitives()[0].listTargets().map(t=>t.getName());
   const values=clip.frames.flatMap(f=>names.map(name=>f.grips[name]??0));
   channel(node,'weights',values,names.length,node.getWeights().length?node.getWeights():names.map(()=>0));
  }
  channel(anchor,'translation',clip.frames.flatMap(f=>f.ball.position),3,null);
  channel(anchor,'rotation',clip.frames.flatMap(f=>f.ball.quaternion),4,null);
  channel(anchor,'scale',clip.frames.flatMap(f=>f.ball.scale),3,null,'STEP');
  clipStatistics.push({id:clip.id,durationSeconds:clip.duration,loop:clip.loop,sourceFrames:clip.frames.length,storedChannels,constantPoseChannels,omittedBindChannels});
 }
 removeDraco(document);
 await document.transform(resample({tolerance:.00003}),prune({keepLeaves:true}),dedup(),sparse({ratio:.15}),draco({method:'edgebreaker',encodeSpeed:5,decodeSpeed:5,quantizePosition:lod?13:14,quantizeNormal:lod?9:11,quantizeTexcoord:lod?11:12,quantizeGeneric:16}));
 g.getAsset().generator='Hoops characters v7 / canonical18 / mesh-aware30Hz original basketball motion / Draco';
 g.getAsset().extras={...(g.getAsset().extras||{}),motion:{sampleHz:hz,resampleTolerance:.00003,source:'source/motion.mjs',presentationOnly:true,rootMotion:false}};
 const bytes=await io.writeBinary(document);
 return{bytes,clipStatistics};
}
try{
 await page.goto(origin+'/bake.html',{waitUntil:'networkidle'});await page.waitForFunction(()=>!!window.__bake,null,{timeout:120000});
 for(const id of ids){
  console.log(`Sampling ${id}: all27actions at${hz}Hz from the actual high-detail mesh.`);
  const profile=authoring.profiles.find(p=>p.id===id);if(!profile)throw Error('Missing authoring profile '+id);
  const samples=await page.evaluate(async({id,profile,rig,hz})=>{
   const e=window.__bake,{THREE,loader,ACTIONS,BONE_NAMES,createMotionController}=e;
   const gltf=await loader.loadAsync('/models/'+id+'.glb'),root=gltf.scene;
   const controller=createMotionController(root,{profile:{...profile,...rig,heightMeters:profile.heightMeters}});
   const clips=[];let maxPalm=0,minSole=Infinity,maxMorphDisagreement=0;
   for(const action of ACTIONS){
    controller.setAction(action.id,{immediate:true});const steps=Math.ceil(action.duration*hz),frames=[];
    for(let i=0;i<=steps;i++){
     controller.seek(i/steps);const snapshot=controller.snapshot();
     for(const name of BONE_NAMES){const bone=snapshot.bones[name];if(!bone||![...bone.position,...bone.quaternion,...bone.scale].every(Number.isFinite))throw Error('Invalid sampled bone '+name);}
     const grips={};for(const morph of snapshot.morphs)for(const[name,index]of Object.entries(morph.targetNames)){const value=morph.weights[index];if(grips[name]!==undefined)maxMorphDisagreement=Math.max(maxMorphDisagreement,Math.abs(grips[name]-value));grips[name]=value;}
     maxPalm=Math.max(maxPalm,snapshot.handContactErrorMeters);for(const v of Object.values(snapshot.soleProbeHeights))if(Number.isFinite(v))minSole=Math.min(minSole,v);
     frames.push({t:action.duration*i/steps,bones:snapshot.bones,grips,ball:snapshot.ballAnchor});
    }
    clips.push({...action,frames});
   }
   controller.dispose();e.truth.set(id,{clips});
   root.traverse(o=>{if(o.isMesh){o.geometry.dispose();for(const m of Array.isArray(o.material)?o.material:[o.material])m.dispose();}});
   return{id,clips,summary:{actions:clips.length,frames:clips.reduce((s,c)=>s+c.frames.length,0),maxPalmResidualMeters:maxPalm,minSoleProbeMeters:Number.isFinite(minSole)?minSole:null,maxMorphDisagreement}};
  },{id,profile,rig:rig.profiles[id],hz});
  if(samples.summary.maxMorphDisagreement>1e-7)throw Error(`Morph primitives disagree for ${id}`);
  const highDoc=await io.readBinary(sourceFiles.get(`/models/${id}.glb`)),highBind=bindRecords(highDoc);
  for(const lod of [0,1]){
   const file=`models/${id}${lod?'-lod1':''}.glb`,document=lod?await io.readBinary(sourceFiles.get('/'+file)):highDoc;
   if(lod)assertSharedBind(highBind,bindRecords(document),id);
   const{bytes,clipStatistics}=await bake(document,samples,id,lod);
   const compressed=validationSummary(await validator.validateBytes(bytes,{uri:file,maxIssues:1000}));
   const decodedDoc=await io.readBinary(bytes);removeDraco(decodedDoc);const decoded=validationSummary(await validator.validateBytes(await io.writeBinary(decodedDoc),{uri:file.replace('.glb','-decoded.glb'),maxIssues:1000}));
   sourceFiles.set('/baked/'+file,Buffer.from(bytes));
   const roundTrip=await page.evaluate(async({id,file})=>{
    const{THREE,loader,BONE_NAMES,truth}=window.__bake,gltf=await loader.loadAsync('/baked/'+file),root=gltf.scene,mixer=new THREE.AnimationMixer(root),bones={},morphs=[];
    root.traverse(o=>{if(o.isBone)bones[o.name]=o;if(o.morphTargetDictionary&&o.morphTargetInfluences)morphs.push(o);});
    const anchor=root.getObjectByName('MotionBallAnchor');if(!anchor)throw Error('Missing baked ball anchor');
    let maxTranslation=0,maxRotation=0,maxScale=0,maxMorph=0,maxBallPosition=0,maxBallRotation=0,maxVisibility=0,samples=0;const clipResults=[];
    for(const source of truth.get(id).clips){
     const clip=gltf.animations.find(a=>a.name===source.id);if(!clip)throw Error('Missing baked clip '+source.id);
     mixer.stopAllAction();const action=mixer.clipAction(clip);action.reset();action.setLoop(THREE.LoopOnce,1);action.clampWhenFinished=true;action.play();
     let clipP=0,clipQ=0;
     for(const expected of source.frames){
      // glTF input timestamps areFLOAT32. Comparing aSTEP visibility marker
      // at the correspondingDOUBLE just before its rounded key is ambiguous.
      mixer.setTime(Math.fround(expected.t));root.updateWorldMatrix(true,true);
      for(const name of BONE_NAMES){const b=bones[name],x=expected.bones[name];if(!b)throw Error('Missing baked bone '+name);const p=b.position.distanceTo(new THREE.Vector3(...x.position)),q=b.quaternion.angleTo(new THREE.Quaternion(...x.quaternion));maxTranslation=Math.max(maxTranslation,p);maxRotation=Math.max(maxRotation,q);clipP=Math.max(clipP,p);clipQ=Math.max(clipQ,q);maxScale=Math.max(maxScale,b.scale.distanceTo(new THREE.Vector3(...x.scale)));}
      for(const mesh of morphs)for(const[name,index]of Object.entries(mesh.morphTargetDictionary))maxMorph=Math.max(maxMorph,Math.abs(mesh.morphTargetInfluences[index]-(expected.grips[name]??0)));
      maxBallPosition=Math.max(maxBallPosition,anchor.position.distanceTo(new THREE.Vector3(...expected.ball.position)));maxBallRotation=Math.max(maxBallRotation,anchor.quaternion.angleTo(new THREE.Quaternion(...expected.ball.quaternion)));maxVisibility=Math.max(maxVisibility,anchor.scale.distanceTo(new THREE.Vector3(...expected.ball.scale)));samples++;
     }
     clipResults.push({action:source.id,durationSeconds:clip.duration,tracks:clip.tracks.length,maxTranslationMeters:clipP,maxRotationRadians:clipQ});
    }
    mixer.stopAllAction();mixer.uncacheRoot(root);root.traverse(o=>{if(o.isMesh){o.geometry.dispose();for(const m of Array.isArray(o.material)?o.material:[o.material])m.dispose();}});
    return{samples,maxTranslationMeters:maxTranslation,maxRotationRadians:maxRotation,maxScale,maxMorphWeightError:maxMorph,maxBallPositionMeters:maxBallPosition,maxBallRotationRadians:maxBallRotation,maxVisibilityScaleError:maxVisibility,clips:clipResults,pass:maxTranslation<.001&&maxRotation<.002&&maxScale<1e-5&&maxMorph<.001&&maxBallPosition<.001&&maxBallRotation<.002&&maxVisibility<1e-5};
   },{id,file});
   const result={file,profile:id,lod,bytes:bytes.length,MB:bytes.length/1e6,sha256:sha(bytes),sourceSha256:sha(sourceFiles.get('/'+file)),compressedKhronos:compressed,decodedKhronos:decoded,roundTrip,clips:clipStatistics,pass:bytes.length<=1500000&&compressed.errors===0&&decoded.errors===0&&roundTrip.pass};
   assets.push(result);staged.set(file,Buffer.from(bytes));await fs.writeFile(path.join(stage,path.basename(file)),bytes);
   console.log(`${result.pass?'PASS':'FAIL'} ${file}: ${bytes.length}B,${clipStatistics.length}clips; positionError=${roundTrip.maxTranslationMeters.toExponential(2)}m; rotationError=${roundTrip.maxRotationRadians.toExponential(2)}rad.`);
  }
  profileSummaries.push({id,...samples.summary});await page.evaluate(id=>window.__bake.truth.delete(id),id);
 }
}catch(error){fatalError=error.stack??String(error);console.error(fatalError);}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
const sourceChanged=[];for(const input of inputHashes){const current=await fs.readFile(path.join(root,input.file));if(sha(current)!==input.sha256)sourceChanged.push(input.file);}
const pass=!fatalError&&assets.length===ids.length*2&&assets.every(a=>a.pass)&&sourceChanged.length===0&&browserErrors.length===0&&externalRequests.length===0;
let written=false;
if(write&&pass){
 for(const[file,bytes]of staged)await fs.writeFile(path.join(root,file+'.next'),bytes);
 for(const[file]of staged)await fs.rename(path.join(root,file+'.next'),path.join(root,file));written=true;
}
const report={schemaVersion:1,startedAtUTC,finishedAtUTC:new Date().toISOString(),scope:'ActualGLBs parsed in Chromium, same mesh-aware canonical solver sampled at30Hz,27 authored clips embedded byNodeIO, then decoded external AnimationMixer playback compared with every source sample. Bone/ball/morph fidelity is measured; gameplay physics and deviceFPS are not implied. LOD1 reuses the corresponding high-detail animation after exact shared-bind checks. Actual LODfloor/hand surfaces are independently audited by validate-skin.mjs.',sampleHz:hz,requestedProfiles:ids,allProfiles:ids.length===ALL_IDS.length,stageDirectory:stage,writeRequested:write,written,inputHashes,sourceChanged,fatalError,browserErrors,externalRequests,profiles:profileSummaries,assets,pass};
await fs.mkdir(path.join(root,'verification'),{recursive:true});await fs.writeFile(path.join(root,'verification/baked-validation.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({pass,written,profiles:ids.length,assets:assets.length,maxBytes:Math.max(0,...assets.map(a=>a.bytes)),stageDirectory:stage,sourceChanged,browserErrors,externalRequests}));
if(!pass)process.exitCode=1;
