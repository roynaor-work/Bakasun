/** Structured upper jersey. Front/back panels plus shoulder bridges create a
 * neck opening and two separate armholes. Source lower garment drape is kept. */
export function upperJersey({THREE,source,world,sx,sy,sz,empty,addVertex,uvRect}) {
 const out=empty(),baseY=world.Chest[1]-.025*sy,neckY=world.Neck[1],centerZ=world.Hips[2];
 const band=[];for(let i=0;i<source.pos.length;i+=3)if(Math.abs(source.pos[i+1]-baseY)<.035*sy)band.push(source.pos.slice(i,i+3));
 const baseHalf=Math.max(.12*sx,...band.map(v=>Math.abs(v[0]))),frontZ=Math.max(centerZ+.095*sz,...band.map(v=>v[2]))+.005*sz,backZ=Math.min(centerZ-.065*sz,...band.map(v=>v[2]))-.005*sz;
 const outerHalf=(Math.abs(world.LeftArm[0])+Math.abs(world.RightArm[0]))*.5*.955,innerHalf=.090*sx;
 const shoulderY=(world.LeftArm[1]+world.RightArm[1])*.5+.025*sy,shoulderZ=(world.LeftArm[2]+world.RightArm[2])*.5;
 const bottomY=Math.min(...source.pos.filter((v,i)=>i%3===1));
 const xs=[...new Set([...Array.from({length:49},(_,i)=>-outerHalf+i/48*outerHalf*2),-innerHalf,innerHalf])].sort((a,b)=>a-b);
 const n=xs.length,rows=12,indices={front:[],back:[]};
 const top=(x,front)=>{const a=Math.abs(x),t=Math.min(1,a/innerHalf);let y=front?neckY-.125*sy+.085*sy*Math.pow(t,1.65):neckY-.025*sy-.015*sy*Math.pow(t,1.4);let z=front?centerZ+(.098-.038*t*t)*sz:centerZ+(-.065+.020*t)*sz;
  if(a>innerHalf){const w=(a-innerHalf)/(outerHalf-innerHalf);y=y*(1-w)+shoulderY*w;z=z*(1-w)+shoulderZ*w;}return {y,z};};
 for(const front of [true,false]){const key=front?'front':'back';for(let row=0;row<=rows;row++){const t=row/rows;for(let col=0;col<n;col++){const xTop=xs[col],u=xTop/outerHalf,x=u*(baseHalf*(1-t)+outerHalf*t),q=top(xTop,front);const y=baseY+(q.y-baseY)*t;
   const zBase=front?centerZ+(frontZ-centerZ)*Math.sqrt(Math.max(.03,1-u*u*.96)):centerZ-(centerZ-backZ)*Math.sqrt(Math.max(.03,1-u*u*.96));
   const z=zBase*(1-t)+q.z*t+.0015*sz*Math.sin(x*75+y*31)*Math.sin(t*Math.PI);
   const uvU=front?.25+x/(4.2*baseHalf):.75-x/(4.2*baseHalf),uvV=1-(y-bottomY)/(neckY+.02*sy-bottomY);
   const chest=.7+.3*Math.min(1,t*3);indices[key].push(addVertex(out,[x,y,z],[0,0,front?1:-1],uvRect(uvU,Math.max(0,Math.min(1,uvV)),'jersey'),[['Chest',chest],['Spine',1-chest]]));
   if(row&&col){const a=indices[key][(row-1)*n+col-1],b=indices[key][(row-1)*n+col],c=indices[key][row*n+col-1],d=indices[key][row*n+col];out.index.push(...(front?[a,b,c,b,d,c]:[c,b,a,c,d,b]));}
  }}}
 // Side seams stop below the armpits; the remaining upper edge is an armhole.
 for(const side of [0,n-1])for(let row=1;row<=3;row++){const a=indices.front[(row-1)*n+side],b=indices.back[(row-1)*n+side],c=indices.front[row*n+side],d=indices.back[row*n+side];out.index.push(...(side===0?[a,c,b,b,c,d]:[a,b,c,b,d,c]));}
 // Shoulder bridges close the outer portions while leaving the neck centre open.
 for(let col=1;col<n;col++){if(Math.abs((xs[col-1]+xs[col])*.5)<innerHalf-.000001)continue;const a=indices.front[rows*n+col-1],b=indices.front[rows*n+col],c=indices.back[rows*n+col-1],d=indices.back[rows*n+col];out.index.push(a,b,c,b,d,c);}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(out.pos,3));g.setIndex(out.index);g.computeVertexNormals();out.norm=Array.from(g.attributes.normal.array);g.dispose();
 return {data:out,baseY};
}
