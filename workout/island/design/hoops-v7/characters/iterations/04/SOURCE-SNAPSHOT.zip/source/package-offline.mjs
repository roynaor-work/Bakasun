/** Authoring utility: packs the local preview into one file:// capable HTML.
 * No build or network access is needed to open the resulting standalone.html.
 * Run: node source/package-offline.mjs --modules /tmp/hoops-v7-tools
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const requested=process.argv.includes('--modules')?process.argv[process.argv.indexOf('--modules')+1]:'/tmp/hoops-v7-tools';
const require=createRequire(path.resolve(requested,'package.json'));
const {build}=require('esbuild');
/** The viewer drives the canonical skeleton itself. Keep full baked clips in
 * the delivered GLBs, but omit their unused bytes from the embedded viewer
 * copies. Geometry, skin weights, inverse binds, textures and morphs are copied
 * byte-for-byte; Draco data is neither decoded nor re-encoded here.
 */
function omitEmbeddedBakedAnimations(input){
  if(input.readUInt32LE(0)!==0x46546c67||input.readUInt32LE(4)!==2)throw Error('Expected GLB v2');
  let json,bin;for(let offset=12;offset<input.length;){const size=input.readUInt32LE(offset),type=input.readUInt32LE(offset+4);const chunk=input.subarray(offset+8,offset+8+size);if(type===0x4e4f534a)json=JSON.parse(chunk.toString('utf8'));if(type===0x004e4942)bin=chunk;offset+=8+size;}
  const clipCount=json?.animations?.length||0;if(!clipCount)return {bytes:input,clipCount:0};
  if(json.buffers?.length!==1||!bin)throw Error('Viewer clip stripping requires one embedded buffer');
  const usedAccessors=new Set(),accessorRefs=[];
  const accessorRef=(object,key)=>{if(object[key]===undefined)return;usedAccessors.add(object[key]);accessorRefs.push([object,key]);};
  for(const mesh of json.meshes||[])for(const primitive of mesh.primitives||[]){accessorRef(primitive,'indices');for(const key of Object.keys(primitive.attributes||{}))accessorRef(primitive.attributes,key);for(const target of primitive.targets||[])for(const key of Object.keys(target))accessorRef(target,key);}
  for(const skin of json.skins||[])accessorRef(skin,'inverseBindMatrices');
  const accessorOrder=[...usedAccessors].sort((a,b)=>a-b),accessorMap=new Map(accessorOrder.map((old,index)=>[old,index]));
  for(const [object,key]of accessorRefs)object[key]=accessorMap.get(object[key]);
  const retainedAccessors=accessorOrder.map(index=>json.accessors[index]);
  const usedViews=new Set(),viewRefs=[];
  const viewRef=(object,key)=>{if(object?.[key]===undefined)return;usedViews.add(object[key]);viewRefs.push([object,key]);};
  for(const accessor of retainedAccessors){viewRef(accessor,'bufferView');viewRef(accessor.sparse?.indices,'bufferView');viewRef(accessor.sparse?.values,'bufferView');}
  for(const image of json.images||[])viewRef(image,'bufferView');
  for(const mesh of json.meshes||[])for(const primitive of mesh.primitives||[])viewRef(primitive.extensions?.KHR_draco_mesh_compression,'bufferView');
  const viewOrder=[...usedViews].sort((a,b)=>a-b),viewMap=new Map(viewOrder.map((old,index)=>[old,index]));
  for(const [object,key]of viewRefs)object[key]=viewMap.get(object[key]);
  let length=0;const parts=[];const retainedViews=viewOrder.map(index=>{const source=json.bufferViews[index];if(source.buffer!==0)throw Error('Unexpected external buffer');if(source.extensions)throw Error('Unexpected bufferView extension; refusing to change encoded data');const offset=source.byteOffset||0,bytes=bin.subarray(offset,offset+source.byteLength);const result={...source,buffer:0,byteOffset:length};parts.push(bytes);length+=bytes.length;const padding=(4-length%4)%4;if(padding){parts.push(Buffer.alloc(padding));length+=padding;}return result;});
  delete json.animations;json.accessors=retainedAccessors;json.bufferViews=retainedViews;json.buffers=[{byteLength:length}];
  const metadata=Buffer.from(JSON.stringify(json));const jsonPadding=(4-metadata.length%4)%4,jsonBytes=Buffer.concat([metadata,Buffer.alloc(jsonPadding,0x20)]),binaryBytes=Buffer.concat(parts);const output=Buffer.alloc(12+8+jsonBytes.length+8+binaryBytes.length);
  output.writeUInt32LE(0x46546c67,0);output.writeUInt32LE(2,4);output.writeUInt32LE(output.length,8);output.writeUInt32LE(jsonBytes.length,12);output.writeUInt32LE(0x4e4f534a,16);jsonBytes.copy(output,20);const offset=20+jsonBytes.length;output.writeUInt32LE(binaryBytes.length,offset);output.writeUInt32LE(0x004e4942,offset+4);binaryBytes.copy(output,offset+8);return {bytes:output,clipCount};
}
const profiles=['pg','sg','sf','pf','c','referee'];
const names=profiles.flatMap(id=>[`models/${id}.glb`,`models/${id}-lod1.glb`]);
names.push('vendor/draco/draco_wasm_wrapper.js','vendor/draco/draco_decoder.wasm');
names.push('rig.json','model-authoring.json');
const files={},embeddedCopies=[];for(const name of names){const original=await fs.readFile(path.join(root,name));const packed=name.endsWith('.glb')&&!process.argv.includes('--include-baked-clips')?omitEmbeddedBakedAnimations(original):{bytes:original,clipCount:0};files[name]=packed.bytes.toString('base64');if(name.endsWith('.glb'))embeddedCopies.push({file:name,deliveredBytes:original.length,embeddedBytes:packed.bytes.length,omittedBakedClips:packed.clipCount});}
const result=await build({entryPoints:[path.join(root,'preview.mjs')],bundle:true,write:false,minify:true,format:'iife',platform:'browser',target:['es2020'],legalComments:'inline'});
const css=await fs.readFile(path.join(root,'preview.css'),'utf8');
let html=await fs.readFile(path.join(root,'index.html'),'utf8');
html=html.replace('<link rel="stylesheet" href="preview.css">',()=>`<style>${css}</style>`);
const pack=JSON.stringify({version:1,files,embeddedCopies}).replace(/<\//g,'<\\/');
const js=result.outputFiles[0].text.replace(/<\/script/gi,'<\\/script');
html=html.replace('<script type="module" src="preview.mjs"></script>',()=>`<script>window.__HOOPS_PACK__=${pack};</script><script>${js}</script>`);
// The report link is useful in the modular preview. The self-contained artifact
// carries a text copy of the report when available, without filesystem requests.
try{const report=await fs.readFile(path.join(root,'REPORT.md'),'utf8');html=html.replace('<a href="REPORT.md">דוח הנכסים והבדיקות ↗</a>','<a href="#" id="offline-report">דוח הנכסים והבדיקות ↗</a>');html=html.replace('</body>',()=>`<script>document.getElementById('offline-report').addEventListener('click',function(event){event.preventDefault();const blob=new Blob([${JSON.stringify(report).replace(/<\//g,'<\\/')}],{type:'text/markdown;charset=utf-8'});const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download='REPORT.md';link.click();setTimeout(function(){URL.revokeObjectURL(link.href)},1000)});</script></body>`);}catch{}
const destination=path.join(root,'standalone.html');await fs.writeFile(destination,html);
console.log(JSON.stringify({path:path.relative(root,destination),bytes:Buffer.byteLength(html),embeddedGLBs:profiles.length*2,embeddedCopies,threeRevision:160,noNetworkRequired:true},null,2));
