/** Canonical18 realistic human pack from read-only repository MakeHuman GLBs.
 * Geometry, maps and weights are preserved where anatomy matters; garment and
 * equipment detail is authored here. No downloaded identities or branded maps.
 * Rebuild: node source/build_characters.mjs [pg|sg|sf|pf|c|referee]
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {upperJersey} from './model_helpers_garments.mjs';
const require=createRequire('/tmp/hoops-v7-tools/package.json');
const {NodeIO,Accessor}=require('@gltf-transform/core');
const {ALL_EXTENSIONS,EXTTextureWebP}=require('@gltf-transform/extensions');
const {dequantize,dedup,prune,weld,simplify,sparse,join,draco}=require('@gltf-transform/functions');
const {MeshoptSimplifier}=require('meshoptimizer');
const dm=require('draco3dgltf');
const sharp=require('sharp');
const THREE=require('three');
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const repo=path.resolve(root,'../../../../..');
const io=new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({'draco3d.encoder':await dm.createEncoderModule(),'draco3d.decoder':await dm.createDecoderModule()});
const PROFILES=[
 {id:'pg',role:'PG',height:1.78,source:'guard',width:.90,depth:.91,number:'07',build:'compact lean playmaker',hair:'close cropped',muscle:.00},
 {id:'sg',role:'SG',height:1.88,source:'wing',width:.97,depth:.96,number:'12',build:'long lean shooting guard',hair:'textured swept crop',muscle:.025},
 {id:'sf',role:'SF',height:1.99,source:'forward',width:1.03,depth:1.025,number:'24',build:'balanced athletic wing',hair:'short textured crop',muscle:.045},
 {id:'pf',role:'PF',height:2.09,source:'big',width:1.12,depth:1.13,number:'35',build:'broad muscular power forward',hair:'rounded coiled afro',muscle:.085},
 {id:'c',role:'C',height:2.20,source:'big',width:.98,depth:1.015,number:'44',build:'long limbed centre with broad shoulders',hair:'flattened coils',muscle:.040},
 {id:'referee',role:'REF',height:1.86,source:'forward',width:.93,depth:.94,number:'00',build:'adult official, neutral athletic build',hair:'short textured crop with sideburns',muscle:.00},
];
const NAMES=['Root','Hips','Spine','Chest','Neck','Head','LeftArm','LeftForeArm','LeftHand','RightArm','RightForeArm','RightHand','LeftUpLeg','LeftLeg','LeftFoot','RightUpLeg','RightLeg','RightFoot'];
const PARENTS=[null,'Root','Hips','Spine','Chest','Neck','Chest','LeftArm','LeftForeArm','Chest','RightArm','RightForeArm','Hips','LeftUpLeg','LeftLeg','Hips','RightUpLeg','RightLeg'];
const MAP={Spine1:'Spine',Spine2:'Chest',LeftShoulder:'Chest',RightShoulder:'Chest',LeftToeBase:'LeftFoot',RightToeBase:'RightFoot'};
const RECTS={skin:[0,0,640,640],face:[640,0,384,768],hair:[0,640,256,128],shoes:[256,640,128,128],eyes:[384,640,128,128],brows:[512,640,64,64],lashes:[576,640,64,64],solid:[512,704,128,64],jersey:[0,768,512,256],shorts:[512,768,512,256]};
const FACE_UV=[.639,.180,.996,.854];
const asName=n=>n.replace('mixamorig:','');
const mapName=n=>{n=asName(n);if(n.includes('Hand'))return n.startsWith('Left')?'LeftHand':'RightHand';return MAP[n]||n;};
const V=a=>new THREE.Vector3(...a);
const list=a=>a.toArray();
const curve=(a,b,x)=>Math.max(0,Math.min(1,(x-a)/(b-a)));
const coord=(a,b,c)=>[a,b,c];
function normalise(a){const s=Math.hypot(...a)||1;return a.map(v=>v/s);}
function uvRect(u,v,r){const [x,y,w,h]=RECTS[r];return [(x+2+u*(w-4))/1024,(y+2+v*(h-4))/1024];}
function uvSkin(u,v){const [x0,y0,x1,y1]=FACE_UV;return u>x0&&u<x1&&v>y0&&v<y1?uvRect((u-x0)/(x1-x0),(v-y0)/(y1-y0),'face'):uvRect(u,v,'skin');}
function sourceRegion(n){return n==='Jersey'?'jersey':n==='Shorts'?'shorts':n.includes('eyebrow')?'brows':n.includes('eyelashes')?'lashes':n.includes('low-poly')?'eyes':n.includes('shoes')?'shoes':/short0\d/.test(n)||n.includes('afro')||n.includes('hair')?'hair':'skin';}
function accumWeights(indices,weights,oldNames){const out=new Map();for(let k=0;k<4;k++){if(weights[k]<1e-7)continue;let name=mapName(oldNames[indices[k]]);let i=NAMES.indexOf(name);if(i<0)i=1;out.set(i,(out.get(i)||0)+weights[k]);}const a=[...out].sort((a,b)=>b[1]-a[1]).slice(0,4);const s=a.reduce((v,p)=>v+p[1],0)||1;while(a.length<4)a.push([0,0]);return [a.map(p=>p[0]),a.map(p=>p[1]/s)];}
function makePrimitive(d,buffer,data,material){data={...data};const cleaned=[];for(let i=0;i<data.index.length;i+=3){const a=data.index[i],b=data.index[i+1],c=data.index[i+2];const v=V(data.pos.slice(a*3,a*3+3)),w=V(data.pos.slice(b*3,b*3+3)).sub(v),q=V(data.pos.slice(c*3,c*3+3)).sub(v);if(w.cross(q).lengthSq()>1e-20)cleaned.push(a,b,c);}data.index=cleaned;const used=[...new Set(data.index)],lookup=new Map(used.map((v,i)=>[v,i]));for(const [key,size]of [['pos',3],['norm',3],['uv',2],['joint',4],['weight',4],['gripLeft',3],['gripRight',3]])data[key]=used.flatMap(i=>data[key].slice(i*size,i*size+size));data.index=data.index.map(i=>lookup.get(i));const p=d.createPrimitive().setMaterial(material);for(const [semantic,values,size,Type]of [['POSITION',data.pos,3,Float32Array],['NORMAL',data.norm,3,Float32Array],['TEXCOORD_0',data.uv,2,Float32Array],['JOINTS_0',data.joint,4,Uint16Array],['WEIGHTS_0',data.weight,4,Float32Array]])p.setAttribute(semantic,d.createAccessor().setType(size===2?'VEC2':size===3?'VEC3':'VEC4').setArray(new Type(values)).setBuffer(buffer));p.setIndices(d.createAccessor().setType('SCALAR').setArray(new Uint32Array(data.index)).setBuffer(buffer));
const iw=new Uint16Array(data.weight.length);for(let i=0;i<iw.length;i+=4){const a=data.weight.slice(i,i+4),sum=a.reduce((s,v)=>s+v,0)||1;const scaled=a.map(v=>v/sum*65535),q=scaled.map(Math.floor),order=[0,1,2,3].sort((a,b)=>(scaled[b]-q[b])-(scaled[a]-q[a]));const remainder=65535-q.reduce((s,v)=>s+v,0);for(let j=0;j<remainder;j++)q[order[j%4]]++;iw.set(q,i);}p.getAttribute('WEIGHTS_0').setArray(iw).setNormalized(true);
if(material.getNormalTexture()){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(data.pos,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(data.norm,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(data.uv,2));g.setIndex(data.index);g.computeTangents();const ta=g.attributes.tangent.array;for(let i=0;i<ta.length;i+=4){let t=new THREE.Vector3(ta[i],ta[i+1],ta[i+2]);if(t.length()<1e-4){const n=new THREE.Vector3(...data.norm.slice(i/4*3,i/4*3+3));const axis=Math.abs(n.x)<.8?new THREE.Vector3(1,0,0):new THREE.Vector3(0,1,0);t.crossVectors(axis,n).normalize();}else t.normalize();ta[i]=t.x;ta[i+1]=t.y;ta[i+2]=t.z;ta[i+3]=ta[i+3]<0?-1:1;}p.setAttribute('TANGENT',d.createAccessor().setType('VEC4').setArray(g.attributes.tangent.array).setBuffer(buffer));g.dispose();}
for(const [name,values]of [['grip_left',data.gripLeft],['grip_right',data.gripRight]]){if(!values)continue;const t=d.createPrimitiveTarget(name);t.setAttribute('POSITION',d.createAccessor().setType('VEC3').setArray(new Float32Array(values)).setBuffer(buffer).setSparse(true));p.addTarget(t);}return p;}
function empty(){return {pos:[],norm:[],uv:[],joint:[],weight:[],index:[],gripLeft:[],gripRight:[]};}
function addVertex(data,p,n,uv,weights){data.pos.push(...p);data.norm.push(...n);data.uv.push(...uv);const a=weights.map(([n,w])=>[NAMES.indexOf(n),w]);while(a.length<4)a.push([0,0]);data.joint.push(...a.slice(0,4).map(p=>p[0]));data.weight.push(...a.slice(0,4).map(p=>p[1]));data.gripLeft.push(0,0,0);data.gripRight.push(0,0,0);return data.pos.length/3-1;}
function addTube(data,points,radii,jointNames,materialRegion='solid',seg=16){for(let k=0;k<points.length;k++){const p=V(points[k]);const axis=V(points[Math.min(k+1,points.length-1)]).sub(V(points[Math.max(k-1,0)])).normalize();let ex=new THREE.Vector3(0,0,1).cross(axis).normalize();if(ex.length()<.01)ex.set(1,0,0);const ez=axis.clone().cross(ex).normalize();for(let s=0;s<=seg;s++){const a=s/seg*Math.PI*2;const n=ex.clone().multiplyScalar(Math.cos(a)).addScaledVector(ez,Math.sin(a));const q=p.clone().addScaledVector(n,radii[k]);addVertex(data,list(q),list(n),uvRect(s/seg,k/(points.length-1),materialRegion),Array.isArray(jointNames[k])?jointNames[k]:[[jointNames[k],1]]);if(k&&s){const i=data.pos.length/3-1,j=i-(seg+1);data.index.push(j-1,j,i-1,j,i,i-1);}}}}
function sphere(data,center,radius,weights,seg=12,rings=8){for(let r=0;r<=rings;r++){const ph=r/rings*Math.PI;for(let s=0;s<=seg;s++){const a=s/seg*Math.PI*2;const n=[Math.sin(ph)*Math.cos(a),Math.cos(ph),Math.sin(ph)*Math.sin(a)];addVertex(data,center.map((v,k)=>v+n[k]*radius[k]),n,uvRect(.5,.5,'solid'),weights);if(r&&s){const i=data.pos.length/3-1,j=i-(seg+1);data.index.push(j-1,j,i-1,j,i,i-1);}}}}
function smoothBoundary(data,passes,blend){const keys=[],positions=new Map(),copies=new Map();for(let i=0;i<data.pos.length/3;i++){const p=data.pos.slice(i*3,i*3+3),k=p.map(v=>Math.round(v*100000)).join(',');keys.push(k);positions.set(k,p);if(!copies.has(k))copies.set(k,[]);copies.get(k).push(i);}const edges=new Map();for(let i=0;i<data.index.length;i+=3)for(let k=0;k<3;k++){const a=keys[data.index[i+k]],b=keys[data.index[i+(k+1)%3]];if(a===b)continue;const key=[a,b].sort().join('|');if(edges.has(key))edges.get(key).count++;else edges.set(key,{a,b,count:1});}const neighbors=new Map();for(const e of edges.values())if(e.count===1){if(!neighbors.has(e.a))neighbors.set(e.a,new Set());if(!neighbors.has(e.b))neighbors.set(e.b,new Set());neighbors.get(e.a).add(e.b);neighbors.get(e.b).add(e.a);}for(let pass=0;pass<passes;pass++){const next=new Map();for(const [k,ns]of neighbors){if(ns.size!==2)continue;const p=positions.get(k),avg=[0,0,0];for(const n of ns){const v=positions.get(n);for(let c=0;c<3;c++)avg[c]+=v[c]/ns.size;}next.set(k,p.map((v,c)=>v*(1-blend)+avg[c]*blend));}for(const [k,v]of next)positions.set(k,v);}for(const [k,ids]of copies){const p=positions.get(k);for(const i of ids)data.pos.splice(i*3,3,...p);}}
function addPiping(data,target,radius,upperTarget=null,splitY=Infinity,minY=-Infinity){const baseTarget=target;
 const keys=[];const merged=new Map();for(let i=0;i<data.pos.length/3;i++){const p=data.pos.slice(i*3,i*3+3);const key=p.map(v=>Math.round(v*100000)).join(',');keys.push(key);if(!merged.has(key))merged.set(key,i);}
 const edges=new Map();for(let i=0;i<data.index.length;i+=3)for(let k=0;k<3;k++){const a=data.index[i+k],b=data.index[i+(k+1)%3],ka=keys[a],kb=keys[b];if(ka===kb)continue;const key=[ka,kb].sort().join('|');if(edges.has(key))edges.get(key).count++;else edges.set(key,{a,b,count:1});}
 for(const edge of edges.values()){if(edge.count!==1)continue;const a=edge.a,b=edge.b;if((data.pos[a*3+1]+data.pos[b*3+1])*.5<minY)continue;target=upperTarget&&(data.pos[a*3+1]+data.pos[b*3+1])*.5>splitY?upperTarget:baseTarget;const p0=V(data.pos.slice(a*3,a*3+3)),p1=V(data.pos.slice(b*3,b*3+3));const axis=p1.clone().sub(p0);if(axis.length()<.001)continue;axis.normalize();const n0=V(data.norm.slice(a*3,a*3+3)),n1=V(data.norm.slice(b*3,b*3+3));const rr=target===upperTarget?radius*1.5:radius;p0.addScaledVector(n0,rr*.25);p1.addScaledVector(n1,rr*.25);let ex=n0.clone().add(n1).normalize();ex.addScaledVector(axis,-ex.dot(axis)).normalize();if(ex.length()<.1)ex=new THREE.Vector3(1,0,0).cross(axis).normalize();const ey=axis.clone().cross(ex).normalize();const first=target.pos.length/3,seg=6;
  for(let r=0;r<2;r++){const p=r?p1:p0,i=r?b:a;const w=data.weight.slice(i*4,i*4+4),j=data.joint.slice(i*4,i*4+4);const ws=j.map((q,k)=>[NAMES[q],w[k]]);for(let k=0;k<=seg;k++){const ph=k/seg*Math.PI*2,n=ex.clone().multiplyScalar(Math.cos(ph)).addScaledVector(ey,Math.sin(ph));addVertex(target,list(p.clone().addScaledVector(n,rr)),list(n),uvRect(.5,.5,'solid'),ws);if(r&&k){const z=first+(seg+1)+k,q=z-(seg+1);target.index.push(q-1,q,z-1,q,z,z-1);}}}
 }
}
function fittedArmSurface(bodySurfaces,world,side,start,end,referee=false){const out=empty(),a=V(world[side+'Arm']),b=V(world[side+'ForeArm']),c=V(world[side+'Hand']),u=b.clone().sub(a),f=c.clone().sub(b),lu=u.length(),lf=f.length();u.normalize();f.normalize();const armId=NAMES.indexOf(side+'Arm'),foreId=NAMES.indexOf(side+'ForeArm'),handId=NAMES.indexOf(side+'Hand');
 const project=p=>{const v=V(p),tu=Math.max(0,Math.min(lu,v.clone().sub(a).dot(u))),tf=Math.max(0,Math.min(lf,v.clone().sub(b).dot(f))),pu=a.clone().addScaledVector(u,tu),pf=b.clone().addScaledVector(f,tf);return v.distanceToSquared(pu)<v.distanceToSquared(pf)?tu:lu+tf;};
 for(const body of bodySurfaces){const accepted=[];for(let i=0;i<body.index.length;i+=3){const ids=body.index.slice(i,i+3),p=[0,0,0];let arm=0;for(const id of ids){for(let k=0;k<3;k++)p[k]+=body.pos[id*3+k]/3;for(let k=0;k<4;k++)if([armId,foreId,handId].includes(body.joint[id*4+k]))arm+=body.weight[id*4+k]/3;}const distance=project(p);if(arm>(referee?.26:.60)&&distance>=lu*start&&distance<=(referee?lu*end:lu+lf*end))accepted.push(...ids);}
  const remap=new Map();for(const id of accepted){if(!remap.has(id)){const index=out.pos.length/3;remap.set(id,index);const p=body.pos.slice(id*3,id*3+3),n=body.norm.slice(id*3,id*3+3);out.pos.push(...p.map((v,k)=>v+n[k]*.004));out.norm.push(...n);if(referee){const d=project(p),q=V(p).sub(a.clone().addScaledVector(u,Math.min(lu,d)));const angle=(Math.atan2(q.z,q.x)+Math.PI)/(2*Math.PI);out.uv.push(...uvRect(angle,d/(lu*.5),'jersey'));}else out.uv.push(...uvRect(.06,.05,'solid'));out.joint.push(...body.joint.slice(id*4,id*4+4));out.weight.push(...body.weight.slice(id*4,id*4+4));out.gripLeft.push(0,0,0);out.gripRight.push(0,0,0);}out.index.push(remap.get(id));}
 }return out;}
function computeNormals(data){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(data.pos,3));g.setIndex(data.index);g.computeVertexNormals();data.norm=Array.from(g.attributes.normal.array);g.dispose();}
async function build(profile){
 const source=path.join(repo,'workout/island/assets/models',`hoops-${profile.source}.glb`);
 const d=await io.read(source);await d.transform(dequantize());
 const oldSkin=d.getRoot().listSkins()[0],oldJoints=oldSkin.listJoints(),oldNames=oldJoints.map(j=>j.getName());
 const oldWorld=Object.fromEntries(oldJoints.map(j=>[asName(j.getName()),Array.from(j.getWorldMatrix())]));
 const fingerDeltas={};for(const side of ['Left','Right']){const a=V(oldWorld[side+'HandIndex1'].slice(12,15)).sub(V(oldWorld[side+'HandPinky1'].slice(12,15))).normalize();const f=V(oldWorld[side+'HandMiddle1'].slice(12,15)).sub(V(oldWorld[side+'Hand'].slice(12,15))).normalize();if(a.clone().cross(f).y<0)a.negate();for(const digit of ['Index','Middle','Ring','Pinky','Thumb']){const M=new THREE.Matrix4();for(let segment=1;segment<=3;segment++){const name=side+'Hand'+digit+segment,p=oldWorld[name].slice(12,15);const angle=digit==='Thumb'?[.07,.18,.1][segment-1]:[.09,.36,.27][segment-1]*(digit==='Pinky'?1.15:digit==='Index'?.9:1);const R=new THREE.Matrix4().makeTranslation(...p).multiply(new THREE.Matrix4().makeRotationAxis(a,angle)).multiply(new THREE.Matrix4().makeTranslation(...p.map(v=>-v)));M.multiply(R);fingerDeltas[name]={side,matrix:M.clone()};}}}
 const meshes=d.getRoot().listNodes().filter(n=>n.getMesh());let min=Infinity,max=-Infinity;
 for(const n of meshes)for(const p of n.getMesh().listPrimitives()){const a=p.getAttribute('POSITION');for(let i=0;i<a.getCount();i++){const v=a.getElement(i,[]);min=Math.min(min,v[1]);max=Math.max(max,v[1]);}}
 const sy=profile.height/(max-min),sx=profile.width,sz=profile.depth;
 let yFix=1;const transform=p=>[p[0]*sx,(p[1]-min)*sy*yFix,p[2]*sz];
 const world={Root:[0,0,0]};for(const name of NAMES.slice(1)){const native=name==='Chest'?'Spine2':name;world[name]=transform(oldWorld[native].slice(12,15));}
 const buffer=d.createBuffer('character');
 const atlas=d.createTexture(profile.id+'-atlas').setImage(await sharp(await fs.readFile(path.join(root,'textures',profile.id+'-atlas.png'))).webp({quality:92,alphaQuality:96}).toBuffer()).setMimeType('image/webp');
 d.createExtension(EXTTextureWebP).setRequired(true);
 const normal=d.createTexture('cloth-normal').setImage(await fs.readFile(path.join(root,'textures/cloth-normal.png'))).setMimeType('image/png');
 const mats={};for(const name of ['skin','eyes','hair','brows','lashes','shoes','team_primary','team_secondary','team_trim','compression','official_uniform','official_trousers']){const m=d.createMaterial(name).setBaseColorTexture(atlas).setRoughnessFactor(name==='eyes'?.22:name==='skin'?.67:.84).setMetallicFactor(0);if(['hair','brows','lashes'].includes(name))m.setAlphaMode('MASK').setAlphaCutoff(.35).setDoubleSided(true);if(name==='team_primary'||name==='team_secondary'||name.startsWith('official_'))m.setNormalTexture(normal).setNormalScale(.8);if(name==='team_primary')m.setBaseColorFactor([.91,.38,.11,1]);if(name==='team_secondary')m.setBaseColorFactor([.065,.12,.16,1]);if(name==='team_trim')m.setBaseColorFactor([.92,.87,.70,1]);if(name==='compression')m.setBaseColorFactor([.09,.12,.14,1]);if(name==='shoes'&&profile.id==='referee')m.setBaseColorFactor([.08,.09,.10,1]);if(name==='official_trousers')m.setBaseColorFactor([.035,.04,.045,1]);mats[name]=m;}
 mats.hair.setBaseColorFactor([.43,.41,.39,1]).setRoughnessFactor(.91);mats.skin.setName('human_surface').setRoughnessFactor(.72);mats.shoes=mats.skin;mats.brows=mats.hair;mats.lashes=mats.hair;
 const canon=NAMES.map(name=>d.createNode(name));for(let i=0;i<NAMES.length;i++){const par=PARENTS[i];canon[i].setTranslation(world[NAMES[i]].map((v,k)=>v-(par?world[par][k]:0)));if(par)canon[NAMES.indexOf(par)].addChild(canon[i]);}
 const ibm=new Float32Array(18*16);for(let i=0;i<18;i++){const p=world[NAMES[i]];ibm.set([1,0,0,0,0,1,0,0,0,0,1,0,-p[0],-p[1],-p[2],1],i*16);}
 const skin=d.createSkin('canonical18').setSkeleton(canon[0]).setInverseBindMatrices(d.createAccessor('inverseBindMatrices').setType('MAT4').setArray(ibm).setBuffer(buffer));canon.forEach(n=>skin.addJoint(n));
 const resultMesh=d.createMesh(profile.id+'-athlete').setExtras({targetNames:['grip_left','grip_right']});const garmentTrim=empty(),garmentNeck=empty(),bodySurfaces=[];
 const chestY=world.Chest[1],hipsY=world.Hips[1],neckY=world.Neck[1];const pieces=[];
 const skinSamples=[];for(const n of meshes.filter(n=>sourceRegion(n.getName())==='skin'))for(const p of n.getMesh().listPrimitives()){const a=p.getAttribute('POSITION'),u=p.getAttribute('TEXCOORD_0');if(!u)continue;for(let i=0;i<a.getCount();i++){const q=a.getElement(i,[]);if(q[1]>oldWorld.Spine2[13]-.04&&Math.abs(q[0])<.23&&q[2]>oldWorld.Hips[14])skinSamples.push({p:q,uv:u.getElement(i,[])});}}
 const skinUV=raw=>{let best=Infinity,result=[.5,.5];for(const s of skinSamples){const dist=s.p.reduce((v,a,k)=>v+(a-raw[k])**2,0);if(dist<best){best=dist;result=s.uv;}}return uvSkin(result[0],result[1]);};
 for(const n of meshes){const region=sourceRegion(n.getName());
 for(const primitive of n.getMesh().listPrimitives()){
  const a=primitive.getAttribute('POSITION'),no=primitive.getAttribute('NORMAL'),uv=primitive.getAttribute('TEXCOORD_0'),ji=primitive.getAttribute('JOINTS_0'),we=primitive.getAttribute('WEIGHTS_0');const data=empty();let rowMin=Infinity,rowMax=-Infinity;
  for(let i=0;i<a.getCount();i++){const raw=a.getElement(i,[]),p=transform(raw);rowMin=Math.min(rowMin,p[1]);rowMax=Math.max(rowMax,p[1]);
   if(region==='skin'){
    // Subtle anatomically distributed shoulder, deltoid and quadriceps volume.
    const t=Math.exp(-(((p[1]-chestY)/(.16*sy))**2));p[0]*=1+profile.muscle*t*.52;p[2]*=1+profile.muscle*t;
    if(profile.id==='c'&&p[1]>neckY){p[0]*=.95;p[2]*=1.015;}
    if(profile.id==='referee'&&p[1]>neckY){p[0]*=1.025;}
   }
   if(region==='hair'&&profile.id==='c'){const h0=neckY+.12; p[1]=h0+(p[1]-h0)*.48;p[0]*=.95;}
   if(region==='jersey'||region==='shorts'){
    const amount=region==='jersey'?.0038:.0045;
    const fold=Math.sin(raw[0]*92+Math.sin(raw[1]*17))*amount+Math.sin(raw[1]*59+raw[0]*27)*amount*.35;
    p[2]+=Math.sign(p[2]-world.Hips[2])*(fold+(region==='jersey'?.007:0));
    // Shorten hems above knees while keeping waistband in place.
    if(region==='shorts'&&profile.id!=='referee'){const w=curve(hipsY-.02,hipsY-.46*sy,p[1]);p[1]+=.055*sy*w;}
   }
   data.pos.push(...p);const nm=no?no.getElement(i,[]):[0,0,1];data.norm.push(...normalise([nm[0]/sx,nm[1]/sy,nm[2]/sz]));
   const u=uv?uv.getElement(i,[]):[.5,.5];data.uv.push(...(region==='skin'?uvSkin(u[0],u[1]):uvRect(Math.max(0,Math.min(1,u[0])),Math.max(0,Math.min(1,u[1])),region)));
   const [j,w]=ji&&we?accumWeights(ji.getElement(i,[]),we.getElement(i,[]),oldNames):[[5,0,0,0],[1,0,0,0]];data.joint.push(...j);data.weight.push(...w);const deltas={Left:new THREE.Vector3(),Right:new THREE.Vector3()};if(region==='skin'&&ji&&we){const sj=ji.getElement(i,[]),sw=we.getElement(i,[]);for(let k=0;k<4;k++){if(sw[k]<1e-7)continue;const fd=fingerDeltas[asName(oldNames[sj[k]])];if(!fd)continue;const target=V(raw).applyMatrix4(fd.matrix).sub(V(raw)).multiplyScalar(sw[k]);deltas[fd.side].add(target);}}data.gripLeft.push(deltas.Left.x*sx,deltas.Left.y*sy,deltas.Left.z*sz);data.gripRight.push(deltas.Right.x*sx,deltas.Right.y*sy,deltas.Right.z*sz);
  }
  data.index=Array.from(primitive.getIndices().getArray());data.fullIndex=data.index.slice();if(region==='jersey'){const top=upperJersey({THREE,source:data,world,sx,sy,sz,empty,addVertex,uvRect});const kept=[];for(let i=0;i<data.index.length;i+=3){const ids=data.index.slice(i,i+3);if(ids.reduce((v,j)=>v+data.pos[j*3+1],0)/3<=top.baseY+.007*sy)kept.push(...ids);}data.index=kept;computeNormals(data);resultMesh.addPrimitive(makePrimitive(d,buffer,top.data,mats[profile.id==='referee'?'official_uniform':'team_primary']));addPiping(top.data,garmentNeck,.0045,null,Infinity,top.baseY+.015*sy);}else if(region==='shorts'){smoothBoundary(data,6,.55);computeNormals(data);if(profile.id!=='referee')addPiping(data,garmentTrim,.0030);}
  const mat=region==='jersey'?(profile.id==='referee'?'official_uniform':'team_primary'):region==='shorts'?(profile.id==='referee'?'official_trousers':'team_secondary'):region;if(region==='skin')bodySurfaces.push(data);
  resultMesh.addPrimitive(makePrimitive(d,buffer,data,mats[mat]));
  // Restore the small sternum area revealed by the lower sewn scoop opening.
  // Its geometry follows the original body-derived garment and its UV colour
  // continues the nearest surviving source clavicle/chest skin chart.
  if(region==='jersey'){const patch=empty();for(let i=0;i<a.getCount();i++){const raw=a.getElement(i,[]),q=transform(raw);q[2]-=.012*sz;patch.pos.push(...q);const nn=no.getElement(i,[]);patch.norm.push(...normalise([nn[0]/sx,nn[1]/sy,nn[2]/sz]));patch.uv.push(...skinUV(raw));patch.joint.push(...data.joint.slice(i*4,i*4+4));patch.weight.push(...data.weight.slice(i*4,i*4+4));patch.gripLeft.push(0,0,0);patch.gripRight.push(0,0,0);}for(let i=0;i<data.fullIndex.length;i+=3){const ids=data.fullIndex.slice(i,i+3);if(ids.every(j=>patch.pos[j*3+1]>chestY+.005&&Math.abs(patch.pos[j*3])<.16*sx&&patch.pos[j*3+2]>world.Hips[2]+.02))patch.index.push(...ids);}if(patch.index.length)resultMesh.addPrimitive(makePrimitive(d,buffer,patch,mats.skin));}
  pieces.push({name:n.getName(),region,triangles:data.index.length/3});
 }}
 // Garment engineering: cylindrical compression sleeve, with turned cuffs.
 const sleeve=empty(),trim=garmentTrim;
 if(profile.id!=='referee'){const side=profile.id==='sg'||profile.id==='c'?'Left':'Right';const wrap=fittedArmSurface(bodySurfaces,world,side,.37,.78);resultMesh.addPrimitive(makePrimitive(d,buffer,wrap,mats.compression));addPiping(wrap,trim,.0025);}
 // Basketball footwear: raised padded ankle collar and six explicit laces.
 const footwear=empty();for(const side of ['Left','Right']){const foot=V(world[side+'Foot']),toe=V(transform(oldWorld[side+'ToeBase'].slice(12,15)));const forward=toe.clone().sub(foot);forward.y=0;forward.normalize();const across=new THREE.Vector3(forward.z,0,-forward.x);const up=V(world[side+'Leg']).sub(foot).normalize();const pts=[foot.clone().addScaledVector(up,.014*sy),foot.clone().addScaledVector(up,.074*sy),foot.clone().addScaledVector(up,.088*sy)];addTube(footwear,pts.map(list),[.055*sx,.049*sx,.045*sx],[side+'Foot',side+'Foot',side+'Foot'],'solid',20);
 for(let k=0;k<6;k++){const c=foot.clone().addScaledVector(forward,.045+.018*k).add(new THREE.Vector3(0,.035*sy-.002*k,0));const a=c.clone().addScaledVector(across,-.026*sx),b=c.clone().addScaledVector(across,.026*sx);addTube(footwear,[list(a),list(b)],[.0017,.0017],[side+'Foot',side+'Foot'],'solid',6);}}
 resultMesh.addPrimitive(makePrimitive(d,buffer,footwear,mats.shoes));
 // Close-trimmed textured sideburns give the hairline a credible side profile.
 for(const sign of [-1,1]){const h=world.Head;const hp=[h[0]+sign*.074*sx,h[1]+.100*sy,h[2]+.029*sz];sphere(sleeve,hp,[.0035*sx,.019*sy,.005*sz],[['Head',1]],10,6);}
 if(sleeve.index.length)resultMesh.addPrimitive(makePrimitive(d,buffer,sleeve,mats.compression));if(trim.index.length)resultMesh.addPrimitive(makePrimitive(d,buffer,trim,mats.team_trim));if(garmentNeck.index.length)resultMesh.addPrimitive(makePrimitive(d,buffer,garmentNeck,mats.team_secondary));
 if(profile.id==='referee'){
  for(const side of ['Left','Right']){const wrap=fittedArmSurface(bodySurfaces,world,side,-.03,.49,true);resultMesh.addPrimitive(makePrimitive(d,buffer,wrap,mats.official_uniform));}
  const pants=empty();for(const side of ['Left','Right']){const a=V(world[side+'UpLeg']),b=V(world[side+'Leg']),c=V(world[side+'Foot']);const p0=a.clone().lerp(b,.68);const p1=b.clone();const p2=c.clone().add(new THREE.Vector3(0,.025*sy,0));addTube(pants,[list(p0),list(a.clone().lerp(b,.85)),list(p1),list(p1.clone().lerp(p2,.7)),list(p2)],[.116*sx,.104*sx,.099*sx,.085*sx,.081*sx],[side+'UpLeg',side+'UpLeg',side+'Leg',side+'Leg',side+'Leg'],'shorts',24);}resultMesh.addPrimitive(makePrimitive(d,buffer,pants,mats.official_trousers));
 }
 // Normalize complete actor after hair reshaping; bones and inverse binds follow.
let lo=Infinity,hi=-Infinity;for(const p of resultMesh.listPrimitives()){const a=p.getAttribute('POSITION');for(let i=0;i<a.getCount();i++){const v=a.getElement(i,[]);lo=Math.min(lo,v[1]);hi=Math.max(hi,v[1]);}}
yFix=profile.height/(hi-lo);for(const p of resultMesh.listPrimitives()){for(const semantic of ['POSITION']){const a=p.getAttribute(semantic);for(let i=0;i<a.getCount();i++){const v=a.getElement(i,[]);v[1]=(v[1]-lo)*yFix;a.setElement(i,v);}}const a=p.getAttribute('NORMAL');for(let i=0;i<a.getCount();i++){const v=a.getElement(i,[]);v[1]/=yFix;a.setElement(i,normalise(v));}for(const t of p.listTargets()){const a=t.getAttribute('POSITION');if(a)for(let i=0;i<a.getCount();i++){const v=a.getElement(i,[]);v[1]*=yFix;a.setElement(i,v);}}}
for(const name of NAMES){world[name][1]=(world[name][1]-lo)*yFix;}world.Root=[0,0,0];for(let i=0;i<NAMES.length;i++){const par=PARENTS[i];canon[i].setTranslation(world[NAMES[i]].map((v,k)=>v-(par?world[par][k]:0)));ibm[i*16+13]=-world[NAMES[i]][1];}skin.getInverseBindMatrices().setArray(ibm);
const scene=d.createScene('hoops-v7');const meshNode=d.createNode(profile.id).setMesh(resultMesh).setSkin(skin);meshNode.setWeights([0,0]);scene.addChild(canon[0]);scene.addChild(meshNode);d.getRoot().setDefaultScene(scene);
 for(const s of [...d.getRoot().listScenes()])if(s!==scene)s.dispose();for(const n of meshes)n.dispose();for(const j of oldJoints)j.dispose();oldSkin.dispose();for(const a of [...d.getRoot().listAnimations()])a.dispose();
 await d.transform(prune(),dedup(),weld(),join({keepMeshes:true}));
 d.getRoot().getAsset().generator='Hoops characters v7; canonical18 + original human mesh; glTF Transform';
 d.getRoot().getAsset().copyright='MakeHuman source provenance: repository ASSETS.md. See LICENSES.md for component limitations.';
 const rawPath=path.join('/tmp/hoops-v7-raw',profile.id+'.glb');await fs.mkdir('/tmp/hoops-v7-raw',{recursive:true});await io.write(rawPath,d);
 await d.transform(sparse({ratio:.15}),draco({method:'edgebreaker',encodeSpeed:5,decodeSpeed:5,quantizePosition:14,quantizeNormal:10,quantizeTexcoord:12,quantizeColor:8,quantizeGeneric:16}));
 await io.write(path.join(root,'models',profile.id+'.glb'),d);
 const tri=d.getRoot().listMeshes().reduce((s,m)=>s+m.listPrimitives().reduce((v,p)=>v+p.getIndices().getCount()/3,0),0);
 const lod=await io.read(rawPath);await MeshoptSimplifier.ready;await lod.transform(simplify({simplifier:MeshoptSimplifier,ratio:.22,error:.025,lockBorder:false}),prune(),dedup(),sparse({ratio:.15}),draco({method:'edgebreaker',encodeSpeed:5,decodeSpeed:5,quantizePosition:13,quantizeNormal:9,quantizeTexcoord:11,quantizeGeneric:16}));await io.write(path.join(root,'models',profile.id+'-lod1.glb'),lod);
 const lodTri=lod.getRoot().listMeshes().reduce((s,m)=>s+m.listPrimitives().reduce((v,p)=>v+p.getIndices().getCount()/3,0),0);
 const joints=NAMES.map((name,i)=>({name,parent:PARENTS[i],translation:canon[i].getTranslation(),rotation:[0,0,0,1],worldPosition:world[name]}));
 const palms={};for(const side of ['Left','Right']){const wrist=V(world[side+'Hand']);const m=oldWorld[side+'HandMiddle1'];const index=oldWorld[side+'HandIndex1'];const pinky=oldWorld[side+'HandPinky1'];const middle=V(transform(m.slice(12,15)));const forward=middle.clone().sub(wrist).normalize();const across=V(transform(index.slice(12,15))).sub(V(transform(pinky.slice(12,15)))).normalize();let palm=across.clone().cross(forward).normalize();if(palm.y<0)palm.negate();const point=wrist.clone().lerp(middle,.65).addScaledVector(palm,.010);palms[side+'Hand']={palmPoint:list(point.clone().sub(wrist)),palmNormal:list(palm),fingerDirection:list(forward),wristWorld:list(wrist),pointWorld:list(point),thumbDirection:list(V(transform(oldWorld[side+'HandThumb3'].slice(12,15))).sub(wrist).normalize()),thumbPoint:list(V(transform(oldWorld[side+'HandThumb3'].slice(12,15))).sub(wrist))};}
 const positions=[];for(const m of d.getRoot().listMeshes())for(const p of m.listPrimitives()){const a=p.getAttribute('POSITION');for(let i=0;i<a.getCount();i++)positions.push(a.getElement(i,[]));}
 const bounds={min:[0,1,2].map(k=>Math.min(...positions.map(p=>p[k]))),max:[0,1,2].map(k=>Math.max(...positions.map(p=>p[k])))};
 const meta={...profile,heightMeters:bounds.max[1]-bounds.min[1],chestWidthMeters:2*.20*sx,triangles:tri,lod1Triangles:lodTri,modelPath:`models/${profile.id}.glb`,lod1Path:`models/${profile.id}-lod1.glb`,bounds,joints,palms,sourcePath:path.relative(repo,source),sourceSha256:(await import('node:crypto')).createHash('sha256').update(await fs.readFile(source)).digest('hex'),atlas:`textures/${profile.id}-atlas.png`,normalAtlas:'textures/cloth-normal.png',pieces,gripMorphs:['grip_left','grip_right']};
 console.log('BUILT',profile.id,tri,lodTri,bounds.max[1]);return meta;
}
await fs.mkdir(path.join(root,'models'),{recursive:true});
const selected=process.argv[2],out=[];for(const profile of PROFILES.filter(p=>!selected||p.id===selected))out.push(await build(profile));
let previous;try{previous=JSON.parse(await fs.readFile(path.join(root,'model-authoring.json'),'utf8'));}catch{previous={profiles:[]};}
const profiles=[...previous.profiles.filter(p=>!out.some(q=>q.id===p.id)),...out].sort((a,b)=>PROFILES.findIndex(p=>p.id===a.id)-PROFILES.findIndex(p=>p.id===b.id));
await fs.writeFile(path.join(root,'model-authoring.json'),JSON.stringify({schemaVersion:1,axes:{up:'+Y',forward:'+Z',anatomicalLeft:'+X'},units:'meters',profiles},null,2)+'\n');
await fs.writeFile(path.join(root,'rig.json'),JSON.stringify({schemaVersion:1,rotationFormat:'quaternion-xyzw',rotationSpace:'parent-local',boneNames:NAMES,parents:PARENTS,profiles:Object.fromEntries(profiles.map(p=>[p.id,{joints:p.joints,palms:p.palms}]))},null,2)+'\n');
